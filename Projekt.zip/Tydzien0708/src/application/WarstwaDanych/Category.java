package application.WarstwaDanych;

import javafx.scene.paint.Color;


/**
 * Konstruktor klasy Category.
 * Tworzy nową kategorię z określoną nazwą i kolorem.
 * 
 * @param name  nazwa kategorii.
 * @param color kolor kategorii.
 */
public class Category {
    private String name;
    private Color color;

    public Category(String name, Color color) {
        this.name = name;
        this.color = color;
    }
    /**
     * Pobiera nazwę kategorii.
     * 
     * @return nazwa kategorii.
     */
    public String getName() {
        return name;
    }
    /**
     * Ustawia nową nazwę kategorii.
     * 
     * @param name nowa nazwa kategorii.
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * Pobiera kolor kategorii.
     * 
     * @return kolor kategorii.
     */
    public Color getColor() {
        return color;
    }
    /**
     * Ustawia nowy kolor kategorii.
     * 
     * @param color nowy kolor kategorii.
     */
    public void setColor(Color color) {
        this.color = color;
    }
    /**
     * Zwraca tekstową reprezentację kategorii.
     * 
     * @return reprezentacja tekstowa kategorii w formacie "nazwa (kolor)".
     */
    @Override
    public String toString() {
        return name + " (" + color.toString() + ")";
    }
}
