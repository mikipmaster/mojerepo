package application.WarstwaDanych;

/**
 * Klasa Contact reprezentuje kontakt w systemie.
 * Zawiera informacje takie jak imię, nazwisko, numer telefonu, kategoria oraz opcjonalnie identyfikator.
 * Klasa implementuje interfejs Comparable, co pozwala na sortowanie kontaktów według ich właściwości.
 * Udostępnia konstruktory do tworzenia nowych kontaktów oraz metody do zarządzania ich danymi.
 */


public class Contact implements Comparable<Contact> {
    private int id;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String category;

    
    /**
     * Konstruktor klasy Contact z id.
     * Tworzy nowy kontakt z określonym id, imieniem, nazwiskiem, numerem telefonu i kategorią.
     * 
     * @param id         unikalny identyfikator kontaktu.
     * @param firstName  imię kontaktu.
     * @param lastName   nazwisko kontaktu.
     * @param phoneNumber numer telefonu kontaktu.
     * @param category   kategoria kontaktu.
     */
    public Contact(int id, String firstName, String lastName, String phoneNumber, String category) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.category = category;
    }

    /**
     * Konstruktor klasy Contact bez id.
     * Tworzy nowy kontakt z określonym imieniem, nazwiskiem, numerem telefonu i kategorią.
     * 
     * @param firstName  imię kontaktu.
     * @param lastName   nazwisko kontaktu.
     * @param phoneNumber numer telefonu kontaktu.
     * @param category   kategoria kontaktu.
     */
    public Contact(String firstName, String lastName, String phoneNumber, String category) {
        this.id = 0; // Zakładamy, że baza danych automatycznie przypisze wartość id
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.category = category;
    }

    /**
     * Pobiera unikalny identyfikator kontaktu.
     * 
     * @return id kontaktu.
     */
    public int getId() {
        return id;
    }
    /**
     * Ustawia nowy identyfikator kontaktu.
     * 
     * @param id nowy identyfikator kontaktu.
     */
    public void setId(int id) {
        this.id = id;
    }
    /**
     * Pobiera imię kontaktu.
     * 
     * @return imię kontaktu.
     */
    public String getFirstName() {
        return firstName;
    }
    /**
     * Ustawia nowe imię kontaktu.
     * 
     * @param firstName nowe imię kontaktu.
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    /**
     * Pobiera nazwisko kontaktu.
     * 
     * @return nazwisko kontaktu.
     */
    public String getLastName() {
        return lastName;
    }

    /**
    * Ustawia nowe nazwisko kontaktu.
    * 
    * @param lastName nowe nazwisko kontaktu.
 	*/
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    /**
     * Pobiera numer telefonu kontaktu.
     * 
     * @return numer telefonu kontaktu.
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * Ustawia nowy numer telefonu kontaktu.
     * 
     * @param phoneNumber nowy numer telefonu kontaktu.
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    /**
     * Pobiera kategorię kontaktu.
     * 
     * @return kategoria kontaktu.
     */
    public String getCategory() {
        return category;
    }
    /**
     * Ustawia nową kategorię kontaktu.
     * 
     * @param category nowa kategoria kontaktu.
     */
    public void setCategory(String category) {
        this.category = category;
    }
    /**
     * Zwraca tekstową reprezentację kontaktu.
     * 
     * @return tekstowa reprezentacja kontaktu w formacie "imię nazwisko | numer telefonu | kategoria".
     */
    @Override
    public String toString() {
        return firstName + " " + lastName + " | " + phoneNumber + " | " + category;
    }

    /**
     * Porównuje kontakty na podstawie nazwiska, a w przypadku równości imienia.
     * 
     * @param other kontakt do porównania.
     * @return wynik porównania: ujemna, zero lub dodatnia wartość.
     */
    @Override
    public int compareTo(Contact other) {
        int lastNameComparison = this.lastName.compareToIgnoreCase(other.lastName);
        if (lastNameComparison != 0) {
            return lastNameComparison;
        }
        return this.firstName.compareToIgnoreCase(other.firstName);
    }
}
