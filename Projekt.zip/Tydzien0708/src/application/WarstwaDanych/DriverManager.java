package application.WarstwaDanych;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Klasa DriverManager zarządza połączeniami z bazą danych oraz przechowuje listy kontaktów i wydarzeń.
 * Odpowiada za:
 * - Ustanawianie połączenia z bazą danych MySQL przy użyciu stałych URL, USER i PASSWORD.
 * - Przechowywanie kontaktów i wydarzeń w listach lokalnych.
 * - Dodawanie kontaktów i wydarzeń do odpowiednich list.
 */


public class DriverManager {
    private static final String URL = "jdbc:mysql://localhost:3306/kalendarz";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    /**
     * Tworzy połączenie z bazą danych.
     * 
     * @return obiekt Connection do bazy danych.
     * @throws SQLException jeśli wystąpi błąd podczas tworzenia połączenia.
     */
    public static Connection getConnection() throws SQLException {
        return java.sql.DriverManager.getConnection(URL, USER, PASSWORD);
    }

    private List<Contact> contacts = new ArrayList<>();
    private List<Event> events = new ArrayList<>();


    /**
     * Dodaje kontakt do listy kontaktów.
     * 
     * @param contact obiekt Contact do dodania.
     */
    public void addContact(Contact contact) {
        if (contact != null) {
            contacts.add(contact);
        }
    }
    /**
     * Dodaje wydarzenie do listy wydarzeń.
     * 
     * @param event obiekt Event do dodania.
     */
    public void addEvent(Event event) {
        if (event != null) {
            events.add(event);
        }
    }

    /**
     * Wczytuje wydarzenia z bazy danych.
     * 
     * @return lista obiektów Event załadowanych z bazy danych.
     */
    public List<Event> loadEventsFromDatabase() {
        events.clear(); // Czyszczenie listy przed załadowaniem
        String query = "SELECT * FROM Events";
        try (Connection connection = getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                Event event = new Event(
                    resultSet.getString("nazwa"),
                    resultSet.getDate("data"),
                    resultSet.getString("opis")
                );
                events.add(event);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return events;
    }

    /**
     * Wczytuje kontakty z bazy danych.
     * 
     * @return lista obiektów Contact załadowanych z bazy danych.
     */
    public List<Contact> loadContactsFromDatabase() {
        contacts.clear(); // Czyszczenie listy przed załadowaniem
        String query = "SELECT id, imie, nazwisko, nr_tel, kategoria FROM contact";
        try (Connection connection = getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                Contact contact = new Contact(
                    resultSet.getInt("id"),
                    resultSet.getString("imie"),
                    resultSet.getString("nazwisko"),
                    resultSet.getString("nr_tel"),
                    resultSet.getString("kategoria")
                );
                contacts.add(contact);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Błąd podczas ładowania kontaktów z bazy: " + e.getMessage());
        }

        return contacts;
    }
    /**
     * Zapisuje listę wydarzeń do bazy danych.
     * Używa zapytania SQL z mechanizmem ON DUPLICATE KEY UPDATE.
     */
    public void saveEventsToDatabase() {
        String query = "INSERT INTO Events (nazwa, data, opis) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE data = VALUES(data), opis = VALUES(opis)";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            for (Event event : events) {
                statement.setString(1, event.getTitle());
                statement.setDate(2, (Date) event.getDate());
                statement.setString(3, event.getDescription());
                statement.executeUpdate();
            }

            System.out.println("Wydarzenia zapisane do bazy.");
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Błąd podczas zapisywania wydarzeń do bazy: " + e.getMessage());
        }
    }
    /**
     * Zapisuje listę kontaktów do bazy danych.
     * Używa zapytania SQL z mechanizmem ON DUPLICATE KEY UPDATE.
     */
    public void saveContactsToDatabase() {
        String query = "INSERT INTO contact (id, imie, nazwisko, nr_tel, kategoria) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE imie = VALUES(imie), nazwisko = VALUES(nazwisko), nr_tel = VALUES(nr_tel), kategoria = VALUES(kategoria)";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            for (Contact contact : contacts) {
                statement.setInt(1, contact.getId());
                statement.setString(2, contact.getFirstName());
                statement.setString(3, contact.getLastName());
                statement.setString(4, contact.getPhoneNumber());
                statement.setString(5, contact.getCategory());
                statement.executeUpdate();
            }

            System.out.println("Kontakty zapisane do bazy.");
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Błąd podczas zapisywania kontaktów do bazy: " + e.getMessage());
        }
    }
}
