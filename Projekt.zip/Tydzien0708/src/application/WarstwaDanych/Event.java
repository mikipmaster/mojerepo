package application.WarstwaDanych;

import java.util.Date;

/**
 * Klasa Event reprezentuje wydarzenie z unikalnym identyfikatorem, tytułem, datą i opisem.
 * Odpowiada za:
 * - Przechowywanie informacji o wydarzeniach, takich jak tytuł, data i opis.
 * - Tworzenie instancji wydarzenia z określonymi lub domyślnymi wartościami.
 * - Możliwość porównywania wydarzeń na podstawie określonych kryteriów (np. daty).
 */


public class Event implements Comparable<Event> {
    private int id;
    private String title;
    private Date date;
    private String description;

    /**
     * Konstruktor klasy Event z id.
     * Tworzy nowe wydarzenie z określonym id, tytułem, datą i opisem.
     * 
     * @param id          unikalny identyfikator wydarzenia.
     * @param title       tytuł wydarzenia.
     * @param date        data wydarzenia.
     * @param description opis wydarzenia.
     */
    public Event(int id, String title, Date date, String description) {
        this.id = id;
        this.title = title;
        this.date = date;
        this.description = description;
    }

    /**
     * Konstruktor klasy Event bez id.
     * Tworzy nowe wydarzenie z określonym tytułem, datą i opisem.
     * 
     * @param title       tytuł wydarzenia.
     * @param date        data wydarzenia.
     * @param description opis wydarzenia.
     */
    public Event(String title, Date date, String description) {
        this.title = title;
        this.date = date;
        this.description = description;
    }

    /**
     * Pobiera unikalny identyfikator wydarzenia.
     * 
     * @return id wydarzenia.
     */
    public int getId() {
        return id;
    }
    /**
     * Ustawia nowy identyfikator wydarzenia.
     * 
     * @param id nowy identyfikator wydarzenia.
     */
    public void setId(int id) {
        this.id = id;
    }
    /**
     * Pobiera tytuł wydarzenia.
     * 
     * @return tytuł wydarzenia.
     */
    public String getTitle() {
        return title;
    }
    /**
     * Ustawia nowy tytuł wydarzenia.
     * 
     * @param title nowy tytuł wydarzenia.
     */
    public void setTitle(String title) {
        this.title = title;
    }
    /**
     * Pobiera datę wydarzenia.
     * 
     * @return data wydarzenia.
     */
    public Date getDate() {
        return date;
    }
    /**
     * Ustawia nową datę wydarzenia.
     * 
     * @param date nowa data wydarzenia.
     */
    public void setDate(Date date) {
        this.date = date;
    }
    /**
     * Pobiera opis wydarzenia.
     * 
     * @return opis wydarzenia.
     */
    public String getDescription() {
        return description;
    }
    
    /**
     * Ustawia nowy opis wydarzenia.
     * 
     * @param description nowy opis wydarzenia.
     */
    public void setDescription(String description) {
        this.description = description;
    }
    /**
     * Zwraca tekstową reprezentację wydarzenia.
     * 
     * @return tekstowa reprezentacja wydarzenia w formacie "tytuł | data | opis".
     */
    @Override
    public String toString() {
        return title + " | " + date + " | " + description;
    }

    /**
     * Porównuje wydarzenia na podstawie daty.
     * 
     * @param other wydarzenie do porównania.
     * @return wynik porównania: ujemna, zero lub dodatnia wartość.
     */
    @Override
    public int compareTo(Event other) {
        return this.date.compareTo(other.date);
    }
}
