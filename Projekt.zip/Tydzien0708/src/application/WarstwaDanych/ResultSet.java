package application.WarstwaDanych;

import java.sql.SQLException;

/**
 * Klasa ResultSet opakowuje obiekt java.sql.ResultSet i zapewnia metody do przetwarzania wyników zapytań SQL.
 * Odpowiada za:
 * - Przechowywanie wyników zapytań SQL w formacie ResultSet.
 * - Wyświetlanie wyników zapytań w czytelnej formie na standardowe wyjście.
 * - Obsługę wyjątków podczas przetwarzania wyników zapytań.
 */


public class ResultSet {
    private java.sql.ResultSet resultSet; 
    /**
     * Konstruktor klasy ResultSet.
     * Tworzy obiekt opakowujący dla wyników zapytania SQL.
     * 
     * @param resultSet obiekt java.sql.ResultSet zawierający wyniki zapytania SQL.
     */

    public ResultSet(java.sql.ResultSet resultSet) {
        this.resultSet = resultSet;
    }

    /**
     * Wypisuje wyniki zapytania SQL na standardowe wyjście.
     * 
     * @throws SQLException jeśli wystąpi błąd podczas przetwarzania wyników.
     */
    public void printResults() throws SQLException {
        while (resultSet.next()) {
            System.out.println("ID: " + resultSet.getInt("id"));
            System.out.println("Imie: " + resultSet.getString("imie"));
            System.out.println("Numer telefonu: " + resultSet.getString("nr_tel"));
            System.out.println("----------------------");
        }
    }

    /**
     * Zamyka obiekt ResultSet i zwalnia zasoby.
     */
    public void close() {
        try {
            if (resultSet != null) {
                resultSet.close();
                System.out.println("Rezultaty zamkniety.");
            }
        } catch (SQLException e) {
            System.err.println("Blad zamykania Rezultaty: " + e.getMessage());
        }
    }
}
