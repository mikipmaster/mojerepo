package application.WarstwaDanych;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Klasa Statement opakowuje obiekt java.sql.Statement i zapewnia metody do wykonywania zapytań SQL.
 * Odpowiada za:
 * - Tworzenie obiektu Statement na podstawie podanego połączenia z bazą danych.
 * - Wykonywanie zapytań SQL typu SELECT oraz zwracanie wyników w postaci ResultSet.
 * - Wykonywanie zapytań SQL typu INSERT, UPDATE lub DELETE.
 * - Obsługę wyjątków podczas wykonywania zapytań SQL.
 */


public class Statement {
    private java.sql.Statement statement;
    /**
     * Konstruktor klasy Statement.
     * Tworzy obiekt do wykonywania zapytań SQL na podanym połączeniu z bazą danych.
     * 
     * @param connection obiekt java.sql.Connection reprezentujący połączenie z bazą danych.
     * @throws SQLException jeśli wystąpi błąd podczas tworzenia obiektu Statement.
     */
    public Statement(java.sql.Connection connection) throws SQLException {
        this.statement = connection.createStatement(); // Tworzenie Stejtment
    }
    /**
     * Wykonuje zapytanie SQL typu SELECT i zwraca wyniki jako ResultSet.
     * 
     * @param query zapytanie SQL typu SELECT do wykonania.
     * @return obiekt ResultSet zawierający wyniki zapytania.
     * @throws SQLException jeśli wystąpi błąd podczas wykonywania zapytania.
     */
    public ResultSet executeQuery(String query) throws SQLException {
        return statement.executeQuery(query);
    }
    /**
     * Wykonuje zapytanie SQL typu INSERT, UPDATE lub DELETE.
     * 
     * @param query zapytanie SQL do wykonania.
     * @return liczba wierszy, które zostały zmodyfikowane przez zapytanie.
     * @throws SQLException jeśli wystąpi błąd podczas wykonywania zapytania.
     */
    public int executeUpdate(String query) throws SQLException {
        return statement.executeUpdate(query);
    }
    /**
     * Zamyka obiekt Statement i zwalnia zasoby.
     */
    public void close() {
        try {
            if (statement != null) {
                statement.close();
                System.out.println("Stejtment zamkniety.");
            }
        } catch (SQLException e) {
            System.err.println("Blad zamykania Stejtment: " + e.getMessage());
        }
    }
}
