package application.WarstwaInterfejsu;

import java.io.IOException;
import java.util.Scanner;
import java.util.List;
import application.WarstwaDanych.Category;
import application.WarstwaDanych.Event;
import application.WarstwaLogiki.CategoryManager;
import application.WarstwaLogiki.ControllerContact;
import application.WarstwaLogiki.ControllerEvent;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import application.WarstwaLogiki.Kalendarz;

	/**
	 * Główna metoda programu.
	 * Odpowiada za zarządzanie kontrolerami oraz tryb tekstowy.
	 */
public class Main extends Application {
    private static boolean isGuiStarted = false;
    private ControllerContact controllerContact;
    private ControllerEvent controllerEvent;
   
    /**
     * Uruchamia graficzny interfejs użytkownika (GUI) aplikacji.
     * 
     * @param primaryStage główna scena aplikacji JavaFX.
     */
    @Override
    public void start(Stage primaryStage) {
        try {
            // Ładowanie głównego kontrolera
            FXMLLoader mainLoader = new FXMLLoader(getClass().getResource("/application/WarstwaInterfejsu/frame.fxml"));
            Parent root = mainLoader.load();
            Scene scene = new Scene(root);
            primaryStage.setScene(scene);
            primaryStage.setTitle("Kalendarz");

         
            
            // Pobranie kontrolery
            FXMLLoader contactLoader = new FXMLLoader(getClass().getResource("/application/WarstwaInterfejsu/frame1.fxml"));
            contactLoader.load();
            controllerContact = contactLoader.getController();

            FXMLLoader eventLoader = new FXMLLoader(getClass().getResource("/application/WarstwaInterfejsu/frame2.fxml"));
            eventLoader.load();
            controllerEvent = eventLoader.getController();
			
            
            
         


            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Błąd podczas ładowania GUI.");
        }
    }

    /**
     * Główna metoda aplikacji.
     * Decyduje, czy uruchomić aplikację w trybie tekstowym, czy graficznym.
     * 
     * @param args argumenty wiersza poleceń. Jeśli przekazany zostanie "text", aplikacja uruchomi się w trybie tekstowym.
     */
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("text")) {
            System.out.println("Uruchamianie programu w trybie tekstowym...");
            runTextMode();
        } else {
            launch(args);
        }
    }
    /**
     * Uruchamia aplikację w trybie tekstowym.
     */
    private static void runTextMode() {
        Kalendarz kalendarz = new Kalendarz(); // Obiekt do zarządzania kontaktami i wydarzeniami
        CategoryManager categoryManager = new CategoryManager(); // Obiekt do zarządzania kategoriami
        Scanner scanner = new Scanner(System.in);
        String input;

        do {
            System.out.println("");
            System.out.println("Witaj! Jesteś w trybie tekstowym kalendarza.");
            System.out.println("Wpisz 'exit', aby zakończyć.");
            System.out.println("Wpisz 'help', aby uzyskać pomoc.");
            System.out.println("");

            System.out.println("=== MENU ===");
            System.out.println("1. Wyświetl kontakty");
            System.out.println("2. Wyświetl wydarzenia");
            System.out.println("3. Dodaj kontakt");
            System.out.println("4. Edytuj kontakt");
            System.out.println("5. Dodaj wydarzenie");
            System.out.println("6. Edytuj wydarzenie");
            System.out.println("7. Dodaj kategorię");
            System.out.println("8. Przypisz kategorię do wydarzenia");
            System.out.println("9. Zapisz kontakty i wydarzenia do bazy danych");
            System.out.println("0. Wyjdź");
            System.out.print("> ");
            input = scanner.nextLine();

            switch (input) {
                case "help":
                    System.out.println("Dostępne komendy:");
                    System.out.println("help - pokazuje dostępne komendy");
                    System.out.println("exit - kończy tryb tekstowy");
                    break;
                case "1": // Wyświetlenie kontaktów
                    kalendarz.displayContacts();
                    break;
                case "2": // Wyświetlenie wydarzeń
                	for (Event event : kalendarz.getEvents()) {
                        Category eventCategory = categoryManager.getCategory(event);
                        System.out.println(event + " -> Kategoria: " + (eventCategory != null ? eventCategory.getName() : "Brak"));
                    }
                    break;
                case "3": // Dodanie kontaktu
                    System.out.print("Podaj imię: ");
                    String firstName = scanner.nextLine();
                    System.out.print("Podaj nazwisko: ");
                    String lastName = scanner.nextLine();
                    System.out.print("Podaj numer telefonu: ");
                    String phoneNumber = scanner.nextLine();
                    System.out.print("Podaj kategorię: ");
                    String category = scanner.nextLine();
                    kalendarz.addContact(firstName, lastName, phoneNumber, category);
                    System.out.println("Dodano kontakt.");
                    break;
                case "4": // Edytowanie kontaktu
                    kalendarz.displayContacts();
                    System.out.print("Podaj indeks kontaktu do edycji: ");
                    int contactIndex = Integer.parseInt(scanner.nextLine());
                    System.out.print("Podaj nowe imię: ");
                    String newFirstName = scanner.nextLine();
                    System.out.print("Podaj nowe nazwisko: ");
                    String newLastName = scanner.nextLine();
                    System.out.print("Podaj nowy numer telefonu: ");
                    String newPhoneNumber = scanner.nextLine();
                    System.out.print("Podaj nową kategorię: ");
                    String newCategory = scanner.nextLine();
                    kalendarz.editContact(contactIndex, newFirstName, newLastName, newPhoneNumber, newCategory);
                    System.out.println("Kontakt zaktualizowany.");
                    break;
                case "5": // Dodanie wydarzenia
                    System.out.print("Podaj nazwę wydarzenia: ");
                    String eventName = scanner.nextLine();
                    System.out.print("Podaj datę wydarzenia (YYYY-MM-DD): ");
                    String eventDate = scanner.nextLine();
                    System.out.print("Podaj opis wydarzenia: ");
                    String eventDescription = scanner.nextLine();
                    kalendarz.addEvent(eventName, eventDate, eventDescription);
                    System.out.println("Dodano wydarzenie.");
                    break;
                case "6": // Edytowanie wydarzenia
                    kalendarz.displayEvents();
                    System.out.print("Podaj indeks wydarzenia do edycji: ");
                    int eventIndex = Integer.parseInt(scanner.nextLine());
                    System.out.print("Podaj nowy tytuł: ");
                    String newTitle = scanner.nextLine();
                    System.out.print("Podaj nową datę (YYYY-MM-DD): ");
                    String newEventDate = scanner.nextLine();
                    System.out.print("Podaj nowy opis wydarzenia: ");
                    String newDescription = scanner.nextLine();
                    kalendarz.editEvent(eventIndex, newTitle, newEventDate, newDescription);
                    System.out.println("Wydarzenie zaktualizowane.");
                    break;
                case "7": // Dodanie kategorii
                    System.out.print("Podaj nazwę kategorii: ");
                    String categoryName = scanner.nextLine();
                    System.out.print("Podaj kolor w formacie HEX (np. #FF5733): ");
                    String colorCode = scanner.nextLine();
                    categoryManager.addCategory(categoryName, colorCode);
                    System.out.println("Dodano kategorię: " + categoryName);
                    break;
                case "8": // Przypisanie kategorii do wydarzenia
                    kalendarz.displayEvents();
                    System.out.print("Wybierz indeks wydarzenia do przypisania kategorii: ");
                    int eventIdx = Integer.parseInt(scanner.nextLine());
                    System.out.println("Dostępne kategorie:");
                    for (Category categoryItem : categoryManager.getCategories()) {
                        System.out.println("- " + categoryItem);
                    }
                    System.out.print("Podaj nazwę kategorii: ");
                    String selectedCategoryName = scanner.nextLine();
                    Category selectedCategory = categoryManager.getCategories()
                            .stream()
                            .filter(c -> c.getName().equalsIgnoreCase(selectedCategoryName))
                            .findFirst()
                            .orElse(null);
                    if (selectedCategory != null) {
                        categoryManager.assignCategory(kalendarz.getEvents().get(eventIdx), selectedCategory);
                        System.out.println("Kategoria przypisana.");
                    } else {
                        System.out.println("Nie znaleziono kategorii.");
                    }
                    break;
                case "9": // Zapis kontaktów i wydarzeń do bazy danych
                    kalendarz.saveContactsToDatabase();
                    kalendarz.saveEventsToDatabase();
                    System.out.println("Dane zostały zapisane do bazy danych.");
                    break;

                case "0": // Wyjście
                    System.out.println("Zamykanie programu.");
                    break;
                default:
                    System.out.println("Nieznana opcja. Spróbuj ponownie.");
            }
        } while (!input.equals("0"));
        scanner.close();
    	}

    }