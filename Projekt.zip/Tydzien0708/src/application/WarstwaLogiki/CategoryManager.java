package application.WarstwaLogiki;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import application.WarstwaDanych.Category;
import javafx.scene.paint.Color;
	/**
	 * Zarządza kategoriami i ich przypisaniami do obiektów.
	 * Umożliwia tworzenie kategorii, przypisywanie ich do obiektów i zarządzanie przypisaniami.
	 */
public class CategoryManager {
    private List<Category> categories; // Lista kategorii
    private Map<Object, Category> categoryAssignments; // Mapowanie obiektow do kategorii
    /**
     * Konstruktor klasy CategoryManager.
     * Tworzy nową instancję menedżera kategorii z pustymi listami kategorii i przypisań.
     */
    public CategoryManager() {
        this.categories = new ArrayList<>();
        this.categoryAssignments = new HashMap<>();
    }

    /**
     * Dodaje nową kategorię do listy.
     * 
     * @param name      nazwa kategorii.
     * @param colorCode kod koloru w formacie HEX (np. #FF5733).
     */
    public void addCategory(String name, String colorCode) {
        categories.add(new Category(name, Color.web(colorCode)));
    }

    /**
     * Pobiera listę wszystkich kategorii.
     * 
     * @return lista obiektów Category.
     */
    public List<Category> getCategories() {
        return categories;
    }

    /**
     * Przypisuje kategorię do obiektu.
     * 
     * @param obj      obiekt, do którego ma być przypisana kategoria.
     * @param category kategoria do przypisania.
     */
    public void assignCategory(Object obj, Category category) {
        categoryAssignments.put(obj, category);
    }

    /**
     * Pobiera kategorię przypisaną do określonego obiektu.
     * 
     * @param obj obiekt, którego przypisana kategoria ma zostać pobrana.
     * @return przypisana kategoria lub null, jeśli brak przypisania.
     */
    public Category getCategory(Object obj) {
        return categoryAssignments.get(obj);
    }


    /**
     * Usuwa przypisanie kategorii do obiektu.
     * 
     * @param obj obiekt, którego przypisanie ma zostać usunięte.
     */
    public void removeCategory(Object obj) {
        categoryAssignments.remove(obj);
    }

    /**
     * Wypisuje wszystkie przypisania kategorii do obiektów.
     * Służy do debugowania.
     */
    public void printAssignments() {
        for (Map.Entry<Object, Category> entry : categoryAssignments.entrySet()) {
            System.out.println("Obiekt: " + entry.getKey() + " -> Kategoria: " + entry.getValue().getName());
        }
    }
}

