package application.WarstwaLogiki;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import application.WarstwaDanych.Contact;

import java.util.Arrays;
	/**
	 * Kontroler dialogu dla dodawania i edycji kontaktów.
	 * Odpowiada za zarządzanie interfejsem dialogowym i walidację danych.
	 */
public class ContactDialogController {
    /**
     * Pole tekstowe dla imienia kontaktu.
     * Powiązane z elementem FXML o fx:id="nameField".
     */
    @FXML
    private TextField nameField;
    /**
     * Pole tekstowe dla nazwiska kontaktu.
     * Powiązane z elementem FXML o fx:id="lastNameField".
     */
    @FXML
    private TextField lastNameField;
    /**
     * Pole tekstowe dla numeru telefonu kontaktu.
     * Powiązane z elementem FXML o fx:id="phoneField".
     */
    @FXML
    private TextField phoneField;
    /**
     * Pole wyboru kategorii kontaktu.
     * Powiązane z elementem FXML o fx:id="categoryComboBox".
     */
    @FXML
    private ComboBox<String> categoryComboBox;
    /**
     * Kontakt, który jest dodawany lub edytowany.
     */
    private Contact contact;
    /**
     * Flaga wskazująca, czy zmiany zostały potwierdzone.
     */
    private boolean confirmed = false;
    /**
     * Inicjalizuje komponenty GUI.
     * Dodaje dostępne kategorie do pola wyboru.
     */
    @FXML
    private void initialize() {
        categoryComboBox.getItems().addAll(Arrays.asList("Rodzina", "Znajomi", "Praca", "Inne", "Szkoła"));
    }
    /**
     * Ustawia kontakt do edycji lub tworzenia.
     * Wypełnia pola formularza danymi kontaktu, jeśli nie jest pusty.
     * 
     * @param contact obiekt Contact do edycji lub null dla nowego kontaktu.
     */
    public void setContact(Contact contact) {
        this.contact = contact;

        if (contact != null) {
            nameField.setText(contact.getFirstName());
            lastNameField.setText(contact.getLastName());
            phoneField.setText(contact.getPhoneNumber());
            categoryComboBox.setValue(contact.getCategory());
        }
    }
    /**
     * Pobiera dane wprowadzone w formularzu jako nowy obiekt Contact.
     * 
     * @return obiekt Contact na podstawie danych z formularza.
     */
    public Contact getContact() {
        return new Contact(
                nameField.getText(),
                lastNameField.getText(),
                phoneField.getText(),
                categoryComboBox.getValue()
        );
    }
    /**
     * Sprawdza, czy zmiany w formularzu zostały potwierdzone.
     * 
     * @return true, jeśli zmiany zostały zapisane; false w przeciwnym wypadku.
     */
    public boolean isConfirmed() {
        return confirmed;
    }
    /**
     * Obsługuje zapis danych w formularzu.
     * Waliduje dane, ustawia flagę potwierdzenia i zamyka dialog.
     */

    @FXML
    private void save() {
        if (isInputValid()) {
            confirmed = true;
            closeDialog();
        } else {
            showAlert("Błąd", "Wszystkie pola muszą być wypełnione!");
        }
    }
    /**
     * Obsługuje anulowanie edycji.
     * Ustawia flagę potwierdzenia na false i zamyka dialog.
     */
    @FXML
    private void cancel() {
        confirmed = false;
        closeDialog();
    }
    /**
     * Sprawdza poprawność danych wprowadzonych w formularzu.
     * 
     * @return true, jeśli dane są poprawne; false w przeciwnym wypadku.
     */
    private boolean isInputValid() {
        return !nameField.getText().isEmpty() &&
                !lastNameField.getText().isEmpty() &&
                !phoneField.getText().isEmpty() &&
                categoryComboBox.getValue() != null;
    }
    /**
     * Zamyka okno dialogowe.
     */
    private void closeDialog() {
        Stage stage = (Stage) nameField.getScene().getWindow();
        stage.close();
    }
    /**
     * Wyświetla alert z komunikatem.
     * 
     * @param title   tytuł okna alertu.
     * @param message treść wiadomości w oknie alertu.
     */
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
