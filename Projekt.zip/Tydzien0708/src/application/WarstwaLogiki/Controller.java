package application.WarstwaLogiki;



import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;



import application.WarstwaDanych.Category;
import application.WarstwaDanych.Contact;
import application.WarstwaDanych.Event;
	/**
	 * Główny kontroler aplikacji zarządzającej kontaktami i wydarzeniami.
	 * Obsługuje interfejs użytkownika, synchronizację z bazą danych i zarządzanie danymi.
	 */
public class Controller {
    /**
     * Siatka dla widoku kalendarza.
     * Powiązana z elementem FXML o fx:id="gridPane".
     */
    @FXML
    private GridPane gridPane;
    /**
     * Aktualna data w kalendarzu.
     */
    private LocalDate currentDate;

    /**
     * Etykieta wyświetlająca nazwę miesiąca.
     * Powiązana z elementem FXML o fx:id="monthLabel".
     */
    @FXML
    private Label monthLabel;
    /**
     * Zakładka dla widoku kontaktów.
     * Powiązana z elementem FXML o fx:id="contactsTab".
     */
    @FXML
    private Tab contactsTab;
    /**
     * Zakładka dla widoku wydarzeń.
     * Powiązana z elementem FXML o fx:id="eventsTab".
     */
    @FXML
    private Tab eventsTab;
    
    /**
     * Lista kontaktów do wyświetlenia.
     */
    private ObservableList<Contact> contactList = FXCollections.observableArrayList();
    

    /**
     * Lista wydarzeń do wyświetlenia.
     */
    private ObservableList<Event> eventList = FXCollections.observableArrayList();
    
    private Kalendarz kalendarz = new Kalendarz(); // Instancja klasy Kalendarz
    
    /**
     * Inicjalizuje widok kontrolera, ładując dane i konfigurując komponenty.
     */
    @FXML
    public void initialize() {
        currentDate = LocalDate.now().withDayOfMonth(1);
        updateCalendar(currentDate);
        loadContactsView();
        loadEventsView();
    }
    /**
     * Inicjalizuje połączenie z bazą danych i ładuje dane kontaktów oraz wydarzeń.
     */
    public void initializeApplication() {
        // Utwórz obiekt klasy DriverManager
        application.WarstwaDanych.DriverManager databaseManager = new application.WarstwaDanych.DriverManager();

        // Wywołaj metody niestatyczne
       List<Event> events = databaseManager.loadEventsFromDatabase();
       List<Contact> contacts = databaseManager.loadContactsFromDatabase();
    }
    
    /**
     * Ładuje widok kontaktów z pliku FXML i ustawia go w odpowiedniej zakładce.
     */
    private void loadContactsView() {
        try {
            VBox contactsContent = FXMLLoader.load(getClass().getResource("/application/WarstwaInterfejsu/frame1.fxml"));
            contactsTab.setContent(contactsContent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /**
     * Ładuje widok wydarzeń z pliku FXML i ustawia go w odpowiedniej zakładce.
     */
    private void loadEventsView() {
        try {
            VBox eventsContent = FXMLLoader.load(getClass().getResource("/application/WarstwaInterfejsu/frame2.fxml"));
            eventsTab.setContent(eventsContent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Zapisuje kontakty do bazy danych.
     * 
     * @param event akcja wywołująca zapis (np. kliknięcie przycisku).
     */ 
    
    //ZAPIS DO BAZY DANYCH NA PRZYCISK
    @FXML
    private void saveContactsToDatabase(ActionEvent event) {
    	try (Connection connection = new application.WarstwaDanych.DriverManager().getConnection()) {
    	    String insertContactQuery = "INSERT INTO contact (imie, nazwisko, nr_tel, kategoria) VALUES (?, ?, ?, ?)";
    	    try (PreparedStatement stmt = connection.prepareStatement(insertContactQuery)) {
    	        for (Contact contact : kalendarz.getContacts()) {
    	            stmt.setString(1, contact.getFirstName());
    	            stmt.setString(2, contact.getLastName());
    	            stmt.setString(3, contact.getPhoneNumber());
    	            stmt.setString(4, contact.getCategory());
    	            stmt.executeUpdate();
    	        }
    	        System.out.println("Kontakty zapisane do bazy danych.");
    	    }
    	} catch (SQLException e) {
    	    System.err.println("Błąd zapisu kontaktów do bazy danych: " + e.getMessage());
    	}

    }

    /**
     * Zapisuje wydarzenia do bazy danych.
     * 
     * @param event akcja wywołująca zapis (np. kliknięcie przycisku).
     */
    @FXML
    private void saveEventsToDatabase(ActionEvent event) {
        try (Connection connection = new application.WarstwaDanych.DriverManager().getConnection()) {
            String insertEventQuery = "INSERT INTO events (nazwa, data, opis) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = connection.prepareStatement(insertEventQuery)) {
                for (Event eventObj : kalendarz.getEvents()) { 
                    stmt.setString(1, eventObj.getTitle());
                    stmt.setDate(2, new java.sql.Date(eventObj.getDate().getTime()));
                    stmt.setString(3, eventObj.getDescription());
                    stmt.executeUpdate();
                }
                System.out.println("Zdarzenia zapisane do bazy danych.");
            }
        } catch (SQLException e) {
            System.err.println("Blad zapisu zdarzeń do bazy danych: " + e.getMessage());
        }
    }
    
    /**
     * Zapisuje kontakty i wydarzenia do pliku XML.
     * 
     * @param event akcja wywołująca zapis (np. kliknięcie przycisku).
     */
    //ZAPIS DO PLIKU XML NA PRZYCISK
    @FXML
    private void saveContactsAndEventsToXml(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Zapisz kontakty i zdarzenia do XML");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Pliki XML", "*.xml"));
        File selectedFile = fileChooser.showSaveDialog(null);

        if (selectedFile != null) {
            System.out.println("Zapisuje dane do pliku: " + selectedFile.getAbsolutePath());
            Kalendarz kalendarz = new Kalendarz(); 
            kalendarz.saveToXml(selectedFile.getAbsolutePath());
        }
    }
    
    /**
     * Ładuje kontakty i wydarzenia z pliku XML.
     * 
     * @param event akcja wywołująca odczyt (np. kliknięcie przycisku).
     */
    // ODCZYT Z PLIKU XML
    @FXML
    private void loadContactsAndEventsFromXml(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Otwórz plik XML");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Pliki XML", "*.xml"));
        File selectedFile = fileChooser.showOpenDialog(null);

        if (selectedFile != null) {
            System.out.println("Odczytuję dane z pliku: " + selectedFile.getAbsolutePath());
            Kalendarz kalendarz = new Kalendarz(); 
            kalendarz.loadFromXml(selectedFile.getAbsolutePath());
        }
    }
	
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    public void saveEventsToDatabase() {
        String insertQuery = """
            INSERT INTO events (id, nazwa, data, opis)
            VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
            nazwa = VALUES(nazwa), data = VALUES(data), opis = VALUES(opis)
        """;

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/kalendarz", "root", "");
             PreparedStatement statement = connection.prepareStatement(insertQuery)) {

            for (Event event : eventList) {
                statement.setInt(1, event.getId());
                statement.setString(2, event.getTitle());
                statement.setDate(3, new java.sql.Date(event.getDate().getTime()));
                statement.setString(4, event.getDescription());
                statement.executeUpdate();
            }

            System.out.println("Wydarzenia zapisane do bazy danych.");
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się zapisać wydarzeń do bazy danych!");
        }
    }
    
    
    @FXML
   	public void saveContactsToDatabaseC() {
           String query = """
               INSERT INTO contact (id, imie, nazwisko, nr_tel, kategoria) 
               VALUES (?, ?, ?, ?, ?)
               ON DUPLICATE KEY UPDATE
               imie = VALUES(imie), nazwisko = VALUES(nazwisko), nr_tel = VALUES(nr_tel), kategoria = VALUES(kategoria)
           """;

           try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/kalendarz", "root", "");
                PreparedStatement statement = connection.prepareStatement(query)) {

               for (Contact contact : contactList) {
                   statement.setInt(1, contact.getId());
                   statement.setString(2, contact.getFirstName());
                   statement.setString(3, contact.getLastName());
                   statement.setString(4, contact.getPhoneNumber());
                   statement.setString(5, contact.getCategory());
                   statement.executeUpdate();
               }

               System.out.println("Kontakty zapisane do bazy danych. Metoda ControllerContact");
           } catch (SQLException e) {
               e.printStackTrace();
               showAlert("Błąd", "Nie udało się zapisać kontaktów do bazy!");
           }
       }
    
    private Map<LocalDate, List<Event>> getEventsForMonth(int year, int month) {
        Map<LocalDate, List<Event>> eventsByDate = new HashMap<>();

        try (Connection connection = new application.WarstwaDanych.DriverManager().getConnection()) { 
            String query = "SELECT nazwa, data, opis FROM events WHERE YEAR(data) = ? AND MONTH(data) = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, year);
                statement.setInt(2, month);

                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        String name = resultSet.getString("nazwa");
                        String date = resultSet.getString("data");
                        String description = resultSet.getString("opis");

                        LocalDate eventDate = LocalDate.parse(date);
                        Event event = new Event(name, java.sql.Date.valueOf(date), description);

                        eventsByDate.computeIfAbsent(eventDate, k -> new ArrayList<>()).add(event);
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Błąd pobierania wydarzeń z bazy danych: " + e.getMessage());
        }

        return eventsByDate;
    }


    private static final String[] MONTHS = {
            "styczeń", "luty", "marzec", "kwiecień", "maj", "czerwiec",
            "lipiec", "sierpień", "wrzesień", "październik", "listopad", "grudzień"
    };
    
    /**
     * Aktualizuje widok kalendarza dla podanej daty.
     * 
     * @param date data, od której ma być zaktualizowany kalendarz.
     */
    private void updateCalendar(LocalDate date) {
        gridPane.getChildren().clear();

        YearMonth yearMonth = YearMonth.from(date);
        int daysInMonth = yearMonth.lengthOfMonth();
        int firstDayOfWeek = date.withDayOfMonth(1).getDayOfWeek().getValue(); // 1 - Poniedziałek, 7 - Niedziela

        // Pobranie wydarzeń dla miesiąca
        Map<LocalDate, List<Event>> eventsByDate = getEventsForMonth(date.getYear(), date.getMonthValue());

        // Ustawienie nazwy miesiąca
        String monthName = MONTHS[yearMonth.getMonthValue() - 1];
        monthLabel.setText(monthName + " " + yearMonth.getYear());

        // Dodawanie nazw dni tygodnia
        String[] daysOfWeek = {"Poniedziałek", "Wtorek", "Środa", "Czwartek", "Piątek", "Sobota", "Niedziela"};
        for (int col = 0; col < 7; col++) {
            Label dayLabel = new Label(daysOfWeek[col]);
            dayLabel.setPrefWidth(120);
            dayLabel.setStyle("-fx-font-weight: bold; -fx-alignment: center; -fx-border-color: gray; -fx-padding: 5;");
            gridPane.add(dayLabel, col, 0);
        }

        LocalDate previousMonth = date.minusMonths(1);
        int daysInPreviousMonth = YearMonth.from(previousMonth).lengthOfMonth();
        int startDayPreviousMonth = daysInPreviousMonth - (firstDayOfWeek - 2);

        int currentDay = 1;
        int nextMonthDay = 1;

        for (int row = 1; row <= 6; row++) {
            for (int col = 0; col < 7; col++) {
                Pane dayPane = new Pane();
                Label dayLabel = new Label();

                if (row == 1 && col < firstDayOfWeek - 1) {
                    // Dni poprzedniego miesiąca
                    dayLabel.setText(String.valueOf(startDayPreviousMonth++));
                    dayLabel.setStyle("-fx-text-fill: lightgray;");
                    dayPane.setStyle("-fx-border-color: lightgray; -fx-background-color: white;");
                } else if (currentDay > daysInMonth) {
                    // Dni następnego miesiąca
                    dayLabel.setText(String.valueOf(nextMonthDay++));
                    dayLabel.setStyle("-fx-text-fill: lightgray;");
                    dayPane.setStyle("-fx-border-color: lightgray; -fx-background-color: white;");
                } else {
                    // Bieżące dni miesiąca
                    LocalDate currentDate = LocalDate.of(yearMonth.getYear(), yearMonth.getMonthValue(), currentDay);
                    dayLabel.setText(String.valueOf(currentDay));
                    dayLabel.setStyle("-fx-text-fill: black;");
                    dayPane.setStyle("-fx-border-color: black; -fx-background-color: white;");

                    if (eventsByDate.containsKey(currentDate)) {
                        dayPane.setStyle("-fx-border-color: black; -fx-background-color: green;");
                        dayPane.setOnMouseClicked(e -> showEventDetails(eventsByDate.get(currentDate)));
                    }

                    currentDay++;
                }

                dayLabel.setStyle("-fx-alignment: center;");
                dayPane.getChildren().add(dayLabel);
                dayPane.setPrefSize(100, 100);
                gridPane.add(dayPane, col, row);
            }
        }
    }


    

    /**
     * Przesuwa widok kalendarza do poprzedniego miesiąca.
     */
    @FXML
    public void previousMonth() {
        currentDate = currentDate.minusMonths(1);
        updateCalendar(currentDate);
    }
    /**
     * Przesuwa widok kalendarza do następnego miesiąca.
     */
    @FXML
    public void nextMonth() {
        currentDate = currentDate.plusMonths(1);
        updateCalendar(currentDate);
    }
    /**
     * Wyświetla okno dialogowe z informacjami o programie.
     * 
     * @param event akcja wywołująca dialog (np. kliknięcie przycisku).
     */
    // O PROGRAMIE
    @FXML
    private void showAboutDialog(ActionEvent event) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("O programie");
        alert.setHeaderText("Informacje o programie");
        alert.setContentText("Ten program to prosty kalendarz stworzony w JavaFX.\nTwórcy: Kacper Każmierczak i Michał Połujański.");
        alert.showAndWait();
    }
    

    /**
     * Wyświetla szczegóły wydarzeń w formie alertu.
     * 
     * @param events lista wydarzeń do wyświetlenia.
     */
    private void showEventDetails(List<Event> events) {
        StringBuilder details = new StringBuilder();
        for (Event event : events) {
            details.append("Tytuł: ").append(event.getTitle())
                   .append("\nOpis: ").append(event.getDescription())
                   .append("\n\n");
        }

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Szczegóły wydarzeń");
        alert.setHeaderText(null);
        alert.setContentText(details.toString());
        alert.showAndWait();
    }
    
    private static void manageAssignments(CategoryManager categoryManager, List<Event> events) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("1. Przypisz kategorie do zdarzenia");
        System.out.println("2. Wyswietl przypisania kategorii");
        System.out.print("> ");
        String choice = scanner.nextLine();

        switch (choice) {
            case "1":
                System.out.println("Dostepne zdarzenia:");
                for (int i = 0; i < events.size(); i++) {
                    System.out.println((i + 1) + ". " + events.get(i));
                }
                System.out.print("Wybierz zdarzenie (numer): ");
                int eventIndex = Integer.parseInt(scanner.nextLine()) - 1;

                System.out.print("Podaj nazwe kategorii: ");
                String categoryName = scanner.nextLine();
                System.out.print("Podaj kolor w formacie HEX (np. #FF5733): ");
                String colorCode = scanner.nextLine();

                Category category = new Category(categoryName, Color.web(colorCode));
                categoryManager.assignCategory(events.get(eventIndex), category);

                System.out.println("Kategoria przypisana.");
                break;

            case "2":
                System.out.println("Przypisania kategorii:");
                categoryManager.printAssignments();
                break;

            default:
                System.out.println("Nieznana opcja.");
        }
    }

    private CategoryManager categoryManager = new CategoryManager();

    public void assignCategoryToEvent(Event event, String categoryName, String colorCode) {
        Category category = new Category(categoryName, Color.web(colorCode));
        categoryManager.assignCategory(event, category);
        System.out.println("Przypisano kategorie: " + categoryName + " do zdarzenia: " + event);
    }

    public void showEventCategories(List<Event> events) {
        for (Event event : events) {
            Category category = categoryManager.getCategory(event);
            System.out.println(event + " -> Kategoria: " + (category != null ? category.getName() : "Brak"));
        }
    }

    private ControllerContact controllerContact;
    private ControllerEvent controllerEvent;
    
    public void initializeControllers() {
        try {
            // Załaduj kontroler dla kontaktów
            FXMLLoader contactLoader = new FXMLLoader(getClass().getResource("/application/WarstwaInterfejsu/frame1.fxml"));
            Parent contactRoot = contactLoader.load();
            controllerContact = contactLoader.getController();

            // Załaduj kontroler dla wydarzeń
            FXMLLoader eventLoader = new FXMLLoader(getClass().getResource("/application/WarstwaInterfejsu/frame2.fxml"));
            Parent eventRoot = eventLoader.load();
            controllerEvent = eventLoader.getController();

            System.out.println("Kontrolery zostały zainicjalizowane.");
        } catch (IOException e) {
            System.err.println("Błąd podczas inicjalizacji kontrolerów: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    public ControllerContact getContactController() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/WarstwaInterfejsu/frame1.fxml"));
            loader.load();
            return loader.getController();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public ControllerEvent getEventController() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/WarstwaInterfejsu/frame2.fxml"));
            loader.load();
            return loader.getController();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

   

    
}
