package application.WarstwaLogiki;

import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import application.WarstwaDanych.Contact;
import application.WarstwaDanych.DriverManager;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;

import java.io.File;
import java.io.FileWriter;
import java.io.Writer;

/**
 * Kontroler zarządzający kontaktami w aplikacji.
 * Obsługuje wyświetlanie, dodawanie, edycję, filtrowanie i usuwanie kontaktów.
 */
public class ControllerContact {
	/**
	 * Tabela wyświetlająca listę kontaktów.
	 * Powiązana z elementem FXML o fx:id="contactTableView".
	 */
    @FXML
    private TableView<Contact> contactTableView;
    /**
     * Kolumna w tabeli wyświetlająca imię kontaktu.
     * Powiązana z elementem FXML o fx:id="contactFirstNameColumn".
     */
    @FXML
    private TableColumn<Contact, String> contactFirstNameColumn;
    /**
     * Kolumna w tabeli wyświetlająca nazwisko kontaktu.
     * Powiązana z elementem FXML o fx:id="contactLastNameColumn".
     */
    @FXML
    private TableColumn<Contact, String> contactLastNameColumn;
    /**
     * Kolumna w tabeli wyświetlająca numer telefonu kontaktu.
     * Powiązana z elementem FXML o fx:id="contactPhoneColumn".
     */
    @FXML
    private TableColumn<Contact, String> contactPhoneColumn;
    /**
     * Kolumna w tabeli wyświetlająca kategorię kontaktu.
     * Powiązana z elementem FXML o fx:id="contactCategoryColumn".
     */
    @FXML
    private TableColumn<Contact, String> contactCategoryColumn;
    /**
     * Pole tekstowe do wprowadzania imienia kontaktu.
     * Powiązane z elementem FXML o fx:id="firstNameField".
     */
    @FXML
    private TextField firstNameField;
    /**
     * Pole tekstowe do wprowadzania nazwiska kontaktu.
     * Powiązane z elementem FXML o fx:id="lastNameField".
     */
    @FXML
    private TextField lastNameField;
    /**
     * Pole tekstowe do wprowadzania numeru telefonu kontaktu.
     * Powiązane z elementem FXML o fx:id="phoneNumberField".
     */
    @FXML
    private TextField phoneNumberField;
    /**
     * Pole tekstowe do wprowadzania kategorii kontaktu.
     * Powiązane z elementem FXML o fx:id="categoryField".
     */
    @FXML
    private TextField categoryField;
    /**
     * ComboBox do wyboru kategorii kontaktu.
     * Powiązany z elementem FXML o fx:id="contactCategoryComboBox".
     */
    @FXML
    private ComboBox<String> contactCategoryComboBox;
    /**
     * Pole tekstowe do filtrowania kontaktów.
     * Powiązane z elementem FXML o fx:id="filterContactsField".
     */
    
    @FXML
    private TextField filterContactsField;
    /**
     * Lista przechowująca nowo dodane kontakty.
     */

    public ObservableList<Contact> newlyAddedContacts = FXCollections.observableArrayList();
    /**
     * Pobiera listę nowo dodanych kontaktów.
     * 
     * @return lista nowo dodanych kontaktów.
     */

    public List<Contact> getNewlyAddedContacts() {
        return new ArrayList<>(newlyAddedContacts);
    }
    /**
     * Czyści listę nowo dodanych kontaktów.
     */

    public void clearNewlyAddedContacts() {
        newlyAddedContacts.clear();
    }
    /**
     * Lista przechowująca wszystkie kontakty.
     */
    public ObservableList<Contact> contactList = FXCollections.observableArrayList();
    /**
     * Pobiera listę wszystkich kontaktów.
     * 
     * @return lista wszystkich kontaktów.
     */
    public ObservableList<Contact> getContactList() {
        return contactList;
    }
    /**
     * Lista przechowująca edytowane kontakty.
     */
    public ObservableList<Contact> editedContacts = FXCollections.observableArrayList();
    /**
     * Lista przechowująca usunięte kontakty.
     */
    public ObservableList<Contact> deletedContacts = FXCollections.observableArrayList();
    
    
    /**
     * Inicjalizuje widok kontrolera, ładując dane i konfigurując komponenty.
     */
    @FXML
    private void initialize() {
        // Powiązanie kolumn z właściwościami Contact
        contactFirstNameColumn.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(cellData.getValue().getFirstName()));
        contactLastNameColumn.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(cellData.getValue().getLastName()));
        contactPhoneColumn.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(cellData.getValue().getPhoneNumber()));
        contactCategoryColumn.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(cellData.getValue().getCategory()));

        // Ustawienie danych tabeli
        contactTableView.setItems(contactList);

        // Wczytaj dane z bazy
        loadContactsFromDatabase();
    }
    /**
     * Ładuje kontakty z bazy danych i ustawia je w widoku tabeli.
     */
    private void loadContactsFromDatabase() {
        String query = "SELECT id, imie, nazwisko, nr_tel, kategoria FROM contact";

        try (Connection connection = DriverManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {

            contactList.clear();
            while (resultSet.next()) {
                Contact contact = new Contact(
                    resultSet.getInt("id"),
                    resultSet.getString("imie"),
                    resultSet.getString("nazwisko"),
                    resultSet.getString("nr_tel"),
                    resultSet.getString("kategoria")
                );
                contactList.add(contact);
            }
            contactTableView.refresh();
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się wczytać kontaktów z bazy danych!");
        }
    }
    /**
     * Obsługuje dodawanie nowego kontaktu.
     * Wyświetla dialog dodawania kontaktu, a następnie dodaje kontakt do listy.
     */
    @FXML
    private void handleAddContact() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/WarstwaInterfejsu/ContactDialog.fxml"));
            VBox dialogVBox = loader.load();

            ContactDialogController dialogController = loader.getController();
            dialogController.setContact(null);

            Stage dialogStage = new Stage();
            dialogStage.initModality(Modality.APPLICATION_MODAL);
            dialogStage.setTitle("Dodaj kontakt");
            dialogStage.setScene(new Scene(dialogVBox));
            dialogStage.showAndWait();

            if (dialogController.isConfirmed()) {
                Contact newContact = dialogController.getContact();
                if (newContact != null) {
                    newlyAddedContacts.add(newContact);
                    contactList.add(newContact);
                    contactTableView.refresh();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się otworzyć okna dialogowego!");
        }
    }

    /**
     * Obsługuje edycję wybranego kontaktu.
     * Wyświetla dialog edycji kontaktu i aktualizuje dane w liście.
     */
    @FXML
    private void handleEditContact()  {
        Contact selectedContact = contactTableView.getSelectionModel().getSelectedItem();
        if (selectedContact != null) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/WarstwaInterfejsu/ContactDialog.fxml"));
                VBox dialogVBox = loader.load();

                ContactDialogController dialogController = loader.getController();
                dialogController.setContact(selectedContact);

                Stage dialogStage = new Stage();
                dialogStage.initModality(Modality.APPLICATION_MODAL);
                dialogStage.setTitle("Edytuj kontakt");
                dialogStage.setScene(new Scene(dialogVBox));
                dialogStage.showAndWait();

                if (dialogController.isConfirmed()) {
                    Contact updatedContact = dialogController.getContact();
                    updatedContact.setId(selectedContact.getId()); // Zachowaj ID kontaktu

                    if (!editedContacts.contains(selectedContact)) {
                        editedContacts.add(updatedContact);
                    } else {
                        int index = editedContacts.indexOf(selectedContact);
                        editedContacts.set(index, updatedContact);
                    }

                    int index = contactList.indexOf(selectedContact);
                    if (index != -1) {
                        contactList.set(index, updatedContact);
                    }
                    contactTableView.refresh();
                }
            } catch (IOException e) {
                e.printStackTrace();
                showAlert("Błąd", "Nie udało się otworzyć okna dialogowego!");
            }
        } else {
            showAlert("Błąd", "Nie wybrano kontaktu do edycji!");
        }
    }
    
    
    
    /**
     * Zapisuje wszystkie kontakty z listy `contactList` do pliku XML.
     *
     * @param filePath ścieżka do pliku, w którym kontakty zostaną zapisane
     */
    
    public void saveContactsToXml(String filePath) {
        XMLOutputFactory factory = XMLOutputFactory.newInstance();

        try (Writer fileWriter = new FileWriter(filePath)) {
            XMLStreamWriter writer = factory.createXMLStreamWriter(fileWriter);

            writer.writeStartDocument("1.0");
            writer.writeCharacters("\n");
            writer.writeStartElement("Contacts");
            writer.writeCharacters("\n");

            for (Contact contact : contactList) {
                writer.writeStartElement("Contact");

                writer.writeStartElement("FirstName");
                writer.writeCharacters(contact.getFirstName());
                writer.writeEndElement();

                writer.writeStartElement("LastName");
                writer.writeCharacters(contact.getLastName());
                writer.writeEndElement();

                writer.writeStartElement("PhoneNumber");
                writer.writeCharacters(contact.getPhoneNumber());
                writer.writeEndElement();

                writer.writeStartElement("Category");
                writer.writeCharacters(contact.getCategory());
                writer.writeEndElement();

                writer.writeEndElement(); // Contact
                writer.writeCharacters("\n");
            }

            writer.writeEndElement(); // Contacts
            writer.writeEndDocument();

            writer.close();
            System.out.println("Kontakty zapisane do pliku XML: " + filePath);
        } catch (Exception e) {
            System.out.println("Błąd zapisu kontaktów do XML: " + e.getMessage());
        }
    }
    
    /**
     * Obsługuje kliknięcie przycisku zapisu kontaktów do pliku XML.
     * Wywołuje okno dialogowe do wyboru lokalizacji pliku, a następnie zapisuje kontakty.
     */
    
    @FXML
    private void handleSaveToXmlButtonAction() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Zapisz kontakty do XML");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Pliki XML", "*.xml"));
        File file = fileChooser.showSaveDialog(null);

        if (file != null) {
            saveContactsToXml(file.getAbsolutePath());
        }
    }
    
    /**
     * Obsługuje filtrowanie kontaktów na podstawie wprowadzonego tekstu.
     */
    //FILTROWANIE KONTAKTOW
    @FXML
    private void filterContacts() {
        String filterText = filterContactsField.getText().toLowerCase();
        List<Contact> filteredContacts = new ArrayList<>();

        for (Contact contact : contactList) {
            if (contact.getFirstName().toLowerCase().contains(filterText) ||
                contact.getLastName().toLowerCase().contains(filterText) ||
                contact.getCategory().toLowerCase().contains(filterText) ||
                String.valueOf(contact.getPhoneNumber()).contains(filterText)) { // Filtruje także numery
                filteredContacts.add(contact);
            }
        }

        // Ustawienie przefiltrowanej listy w tabeli
        contactTableView.setItems(FXCollections.observableArrayList(filteredContacts));
        highlightMatches(contactFirstNameColumn, filterText);
        highlightMatches(contactLastNameColumn, filterText);
        highlightMatches(contactPhoneColumn, filterText);
        highlightMatches(contactCategoryColumn, filterText);
        System.out.println("Kontakty zostały przefiltrowane.");
    }
    /**
     * Resetuje filtr kontaktów i przywraca pełną listę kontaktów w tabeli.
     */
    //RESET FILTROW
    @FXML
    private void resetFilter() {
        contactTableView.setItems(contactList);
        
        highlightMatches(contactFirstNameColumn, "");
        highlightMatches(contactLastNameColumn, "");
        highlightMatches(contactCategoryColumn, "");
        highlightMatches(contactPhoneColumn, "");
        System.out.println("Filtr został zresetowany.");
    }
    
    //PODSWIETLANIE FILTROW
    private void highlightMatches(TableColumn<Contact, String> column, String filterText) {
        column.setCellFactory(col -> new TableCell<Contact, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                if (empty || item == null) {
                    setText(null);
                    setStyle(""); 
                } else {
                    setText(item);

                    if (!filterText.isEmpty() && item.toLowerCase().contains(filterText.toLowerCase())) {
                        setStyle("-fx-background-color: green; -fx-text-fill: black;");
                    } else {
                        setStyle(""); 
                    }
                }
            }
        });
    }
    /**
     * Otwiera okno dialogowe do dodania lub edycji kontaktu.
     * Jeśli kontakt jest null, otwiera dialog dodawania kontaktu.
     * Jeśli kontakt jest nie-null, otwiera dialog edycji kontaktu i aktualizuje dane.
     * 
     * @param contact obiekt Contact do edycji lub null, jeśli dodawany jest nowy kontakt.
     */
    private void openContactDialog(Contact contact) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/WarstwaInterfejsu/ContactDialog.fxml"));
            VBox dialogVBox = loader.load();

            ContactDialogController dialogController = loader.getController();
            dialogController.setContact(contact);

            Stage dialogStage = new Stage();
            dialogStage.initModality(Modality.APPLICATION_MODAL);
            dialogStage.setTitle(contact == null ? "Dodaj kontakt" : "Edytuj kontakt");
            dialogStage.setScene(new Scene(dialogVBox));
            dialogStage.showAndWait();

            if (dialogController.isConfirmed()) {
                Contact updatedContact = dialogController.getContact();
                if (contact == null) {
                    contactList.add(updatedContact);
                } else {
                    contactList.remove(contact);
                    contactList.add(updatedContact);
                }
                contactTableView.refresh();
            }
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się otworzyć okna dialogowego!");
        }
    }
    /**
     * Generuje unikalne ID dla nowego kontaktu.
     * ID jest większe o 1 od obecnego maksimum w liście kontaktów.
     * 
     * @return unikalny numer ID dla kontaktu.
     */
    private int generateUniqueId() {
        return contactList.stream()
            .mapToInt(Contact::getId)
            .max()
            .orElse(0) + 1; // Generuje ID większe od obecnego maksimum
    }
    /**
     * Zapisuje kontakty do bazy danych.
     * Aktualizuje, wstawia lub usuwa kontakty na podstawie ich statusu.
     */
    public void saveContactsToDatabase() {
        String updateQuery = """
            UPDATE contact
            SET imie = ?, nazwisko = ?, nr_tel = ?, kategoria = ?
            WHERE id = ?
        """;

        String insertQuery = """
            INSERT INTO contact (id, imie, nazwisko, nr_tel, kategoria)
            VALUES (?, ?, ?, ?, ?)
        """;

        String deleteQuery = """
            DELETE FROM contact
            WHERE id = ?
        """;

        try (Connection connection = DriverManager.getConnection();
             PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
             PreparedStatement insertStatement = connection.prepareStatement(insertQuery);
             PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery)) {

           
        	  for (Contact contact : deletedContacts) {
                  deleteStatement.setInt(1, contact.getId());
                  deleteStatement.executeUpdate();
              }
        	
            for (Contact contact : editedContacts) {
                updateStatement.setString(1, contact.getFirstName());
                updateStatement.setString(2, contact.getLastName());
                updateStatement.setString(3, contact.getPhoneNumber());
                updateStatement.setString(4, contact.getCategory());
                updateStatement.setInt(5, contact.getId());
                updateStatement.executeUpdate();
            }

            for (Contact contact : newlyAddedContacts) {
                insertStatement.setInt(1, contact.getId());
                insertStatement.setString(2, contact.getFirstName());
                insertStatement.setString(3, contact.getLastName());
                insertStatement.setString(4, contact.getPhoneNumber());
                insertStatement.setString(5, contact.getCategory());
                insertStatement.executeUpdate();
            }

          
            
            System.out.println("Kontakty zostały zapisane do bazy danych.");
            editedContacts.clear();
            newlyAddedContacts.clear();
            deletedContacts.clear();
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się zapisać kontaktów do bazy danych!");
        }
    }

   


    /**
     * Obsługuje usuwanie wybranego kontaktu z listy.
     * Dodaje kontakt do listy usuniętych kontaktów.
     */
    
    @FXML
    private void handleDeleteContact() {
        Contact selectedContact = contactTableView.getSelectionModel().getSelectedItem();
        if (selectedContact != null) {
            contactList.remove(selectedContact);
            if (!deletedContacts.contains(selectedContact)) {
                deletedContacts.add(selectedContact);
            }
            contactTableView.refresh();
        } else {
            showAlert("Błąd", "Nie wybrano kontaktu do usunięcia!");
        }
    }
    
    
    /**
     * Wyświetla alert z komunikatem.
     * 
     * @param title   tytuł alertu.
     * @param message treść wiadomości w alertu.
     */
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
