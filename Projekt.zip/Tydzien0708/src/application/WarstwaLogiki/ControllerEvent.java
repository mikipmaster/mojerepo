package application.WarstwaLogiki;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;

import javafx.beans.property.SimpleStringProperty;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;

import java.io.File;
import java.io.FileWriter;
import java.io.Writer;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;

import application.WarstwaDanych.DriverManager;
import application.WarstwaDanych.Event;
	/**
	 * Kontroler zarządzający wydarzeniami w aplikacji.
	 * Obsługuje dodawanie, edycję, usuwanie, filtrowanie i zapis wydarzeń.
	 */
public class ControllerEvent {
    /**
     * Tabela wyświetlająca listę wydarzeń.
     * Powiązana z elementem FXML o fx:id="eventTableView".
     */
    @FXML
    private TableView<Event> eventTableView;
    /**
     * Kolumna tabeli wyświetlająca tytuł wydarzenia.
     * Powiązana z elementem FXML o fx:id="eventNameColumn".
     */
    @FXML
    private TableColumn<Event, String> eventNameColumn;
    /**
     * Kolumna tabeli wyświetlająca datę wydarzenia.
     * Powiązana z elementem FXML o fx:id="eventDateColumn".
     */
    @FXML
    private TableColumn<Event, String> eventDateColumn;
    /**
     * Kolumna tabeli wyświetlająca opis wydarzenia.
     * Powiązana z elementem FXML o fx:id="eventDescriptionColumn".
     */
    @FXML
    private TableColumn<Event, String> eventDescriptionColumn;
    /**
     * Pole tekstowe do wprowadzania nazwy wydarzenia.
     * Powiązane z elementem FXML o fx:id="eventNameField".
     */
    @FXML
    private TextField eventNameField;
    /**
     * Pole tekstowe do wprowadzania daty wydarzenia.
     * Powiązane z elementem FXML o fx:id="eventDateField".
     */
    @FXML
    private TextField eventDateField;
    /**
     * Pole tekstowe do wprowadzania opisu wydarzenia.
     * Powiązane z elementem FXML o fx:id="eventDescriptionField".
     */
    @FXML
    private TextField eventDescriptionField;
    /**
     * Pole tekstowe do filtrowania wydarzeń.
     * Powiązane z elementem FXML o fx:id="filterEventsField".
     */
    @FXML
    private TextField filterEventsField;
    
    
    
    /**
     * Lista przechowująca nowo dodane wydarzenia.
     */
    
    public ObservableList<Event> newlyAddedEvents = FXCollections.observableArrayList();
    
    /**
     * Pobiera listę nowo dodanych wydarzeń.
     * 
     * @return lista nowo dodanych wydarzeń.
     */
    public List<Event> getNewlyAddedEvents() {
        return new ArrayList<>(newlyAddedEvents); // Zwraca kopię listy
    }
    
    /**
     * Czyści listę nowo dodanych wydarzeń.
     */
    public void clearNewlyAddedEvents() {
        newlyAddedEvents.clear(); // Czyści listę newlyAddedEvents
    }

    /**
     * Lista przechowująca wszystkie wydarzenia.
     */
    
    public ObservableList<Event> eventList = FXCollections.observableArrayList();
    
    /**
     * Pobiera listę wszystkich wydarzeń.
     * 
     * @return lista wszystkich wydarzeń.
     */
    public ObservableList<Event> getEventList() {
        return eventList;
    }
    
    /**
     * Lista przechowująca edytowane wydarzenia.
     */

    public ObservableList<Event> editedEvents = FXCollections.observableArrayList();
   

    /**
     * Lista przechowująca usunięte wydarzenia.
     */
    public ObservableList<Event> deletedEvents = FXCollections.observableArrayList();
    
   
    /**
     * Inicjalizuje widok kontrolera, ładując dane i konfigurując komponenty.
     */
    @FXML
    private void initialize() {
        eventNameColumn.setCellValueFactory(new PropertyValueFactory<>("title"));

        eventDateColumn.setCellValueFactory(cellData -> {
            Date date = cellData.getValue().getDate(); 
            String formattedDate = date != null ? new SimpleDateFormat("yyyy-MM-dd").format(date) : ""; 
            return new SimpleStringProperty(formattedDate);
        });

        eventDescriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));

        eventTableView.setItems(eventList);
        loadEventsFromDatabase();
    }

   
    /**
     * Ładuje wydarzenia z bazy danych i ustawia je w widoku tabeli.
     */
    private void loadEventsFromDatabase() {
        try (Connection connection = DriverManager.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT id, nazwa, data, opis FROM events");
             ResultSet resultSet = statement.executeQuery()) {

            eventList.clear(); 

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String title = resultSet.getString("nazwa");
                java.sql.Date sqlDate = resultSet.getDate("data"); 
                String description = resultSet.getString("opis");

                // Konwersja java.sql.Date na java.util.Date
                Date date = sqlDate != null ? new Date(sqlDate.getTime()) : null;

                // Dodanie wydarzenia do listy
                eventList.add(new Event(id, title, date, description));
            }
        } catch (SQLException e) {
            System.err.println("Błąd podczas ładowania wydarzeń z bazy danych: " + e.getMessage());
        }
    }



    /**
     * Obsługuje dodawanie nowego wydarzenia.
     * Wyświetla dialog dodawania wydarzenia i dodaje je do listy.
     */
    // DODANIE EVENTU
    @FXML
    private void addEvent() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/WarstwaInterfejsu/EventDialog.fxml"));
            VBox dialogVBox = loader.load();

            EventDialogController dialogController = loader.getController();
            dialogController.setEvent(null);

            Stage dialogStage = new Stage();
            dialogStage.initModality(Modality.APPLICATION_MODAL);
            dialogStage.setTitle("Dodaj wydarzenie");
            dialogStage.setScene(new Scene(dialogVBox));
            dialogStage.showAndWait();

            if (dialogController.isConfirmed()) {
                Event newEvent = dialogController.getEvent();
                if (newEvent != null) {
                    newlyAddedEvents.add(newEvent);
                    eventList.add(newEvent);
                    eventTableView.refresh();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się otworzyć okna dialogowego!");
        }
    }

    /**
     * Obsługuje edycję wybranego wydarzenia.
     * Wyświetla dialog edycji wydarzenia i aktualizuje dane w liście.
     */
    @FXML
    private void editEvent() {
        Event selectedEvent = eventTableView.getSelectionModel().getSelectedItem();
        if (selectedEvent != null) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/WarstwaInterfejsu/EventDialog.fxml"));
                VBox dialogVBox = loader.load();

                EventDialogController dialogController = loader.getController();
                dialogController.setEvent(selectedEvent); // Wczytaj dane do dialogu

                Stage dialogStage = new Stage();
                dialogStage.initModality(Modality.APPLICATION_MODAL);
                dialogStage.setTitle("Edytuj wydarzenie");
                dialogStage.setScene(new Scene(dialogVBox));
                dialogStage.showAndWait();

                if (dialogController.isConfirmed()) {
                    Event updatedEvent = dialogController.getEvent();
                    if (updatedEvent != null) {
                        // Nadpisz dane w liście
                        int index = eventList.indexOf(selectedEvent);
                        if (index != -1) {
                            eventList.set(index, updatedEvent);

                            // Dodaj zaktualizowane wydarzenie do listy edytowanych
                            if (!editedEvents.contains(selectedEvent)) {
                                editedEvents.add(updatedEvent);
                            }
                        }
                        eventTableView.refresh();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
                showAlert("Błąd", "Nie udało się otworzyć okna dialogowego!");
            }
        } else {
            showAlert("Błąd", "Nie wybrano wydarzenia do edycji!");
        }
    }

    
    /**
     * Obsługuje usuwanie wybranego wydarzenia z listy.
     */
    @FXML
    private void deleteEvent() {
        Event selectedEvent = eventTableView.getSelectionModel().getSelectedItem();
        if (selectedEvent != null) {
            // Usuń wydarzenie z listy głównej
            eventList.remove(selectedEvent);

            // Dodaj do listy usuniętych wydarzeń
            if (!deletedEvents.contains(selectedEvent)) {
                deletedEvents.add(selectedEvent);
            }

            // Odśwież tabelę
            eventTableView.refresh();
            showAlert("Sukces", "Wydarzenie zostało usunięte!");
        } else {
            showAlert("Błąd", "Nie wybrano wydarzenia do usunięcia!");
        }
    }
    
    /**
     * Filtrowanie wydarzeń na podstawie wprowadzonego tekstu.
     * Wyszukiwanie odbywa się po tytule, opisie i dacie wydarzenia.
     * 
     * Przefiltrowane wydarzenia są wyświetlane w tabeli, a dopasowania
     * w kolumnach zostają podświetlone.
     */
    
    //FILTROWANIE WYDARZEN
    @FXML
    private void filterEvents() {
        String filterText = filterEventsField.getText().toLowerCase();
        List<Event> filteredEvents = new ArrayList<>();

        for (Event event : eventList) {
            // Konwersja daty na String dla porównania
            String dateAsString = event.getDate() != null ? event.getDate().toString() : "";

            if (event.getTitle().toLowerCase().contains(filterText) ||
                event.getDescription().toLowerCase().contains(filterText) ||
                dateAsString.contains(filterText)) { // Użycie daty jako String
                filteredEvents.add(event);
            }
        }

        // Ustawienie przefiltrowanej listy w tabeli
        eventTableView.setItems(FXCollections.observableArrayList(filteredEvents));

        // Podświetlanie w każdej kolumnie
        highlightEventMatches(eventNameColumn, filterText);
        highlightEventMatches(eventDescriptionColumn, filterText);
        highlightEventMatches(eventDateColumn, filterText);

        System.out.println("Wydarzenia zostały przefiltrowane.");
    }
    
    /**
     * Resetuje filtr wydarzeń, przywracając pełną listę wydarzeń w tabeli.
     * Usuwa również podświetlenia w kolumnach.
     */
    
    //RESET FILTROW
    @FXML
    private void resetFilter() {
        eventTableView.setItems(eventList);
        highlightEventMatches(eventNameColumn, "");
        highlightEventMatches(eventDescriptionColumn, "");
        highlightEventMatches(eventDateColumn, "");
        System.out.println("Filtr został zresetowany.");
    }
    
    /**
     * Podświetla dopasowania w podanej kolumnie tabeli na podstawie tekstu filtru.
     * Jeśli komórka zawiera tekst zgodny z filtrem, zmienia tło na zielone.
     * 
     * @param column     kolumna tabeli, w której mają być podświetlane dopasowania.
     * @param filterText tekst filtru używany do porównania.
     */
    
    //PODSWIETLANIE FILTROW
    private void highlightEventMatches(TableColumn<Event, String> column, String filterText) {
        column.setCellFactory(col -> new TableCell<Event, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                if (empty || item == null) {
                    setText(null);
                    setStyle(""); 
                } else {
                    setText(item);

                    if (!filterText.isEmpty() && item.toLowerCase().contains(filterText.toLowerCase())) {
                        setStyle("-fx-background-color: green; -fx-text-fill: black;");
                    } else {
                        setStyle(""); 
                    }
                }
            }
        });
    }

    /**
     * Zapisuje wydarzenia do bazy danych, aktualizując zmienione, wstawiając nowe
     * i usuwając wydarzenia oznaczone do usunięcia.
     * 
     * Po zapisaniu wyczyszczone zostają listy nowych, edytowanych i usuniętych wydarzeń.
     */
    
    public void saveEventsToDatabase() {
        String updateQuery = """
            UPDATE events
            SET nazwa = ?, data = ?, opis = ?
            WHERE id = ?
        """;

        String insertQuery = """
            INSERT INTO events (id, nazwa, data, opis)
            VALUES (?, ?, ?, ?)
        """;

        String deleteQuery = """
            DELETE FROM events
            WHERE id = ?
        """;

        try (Connection connection = DriverManager.getConnection();
             PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
             PreparedStatement insertStatement = connection.prepareStatement(insertQuery);
             PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery)) {

            // Aktualizuj zmienione wydarzenia
            for (Event event : editedEvents) {
                updateStatement.setString(1, event.getTitle());
                updateStatement.setDate(2, new java.sql.Date(event.getDate().getTime()));
                updateStatement.setString(3, event.getDescription());
                updateStatement.setInt(4, event.getId()); // Klucz id do zaktualizowania rekordu
                updateStatement.executeUpdate();
            }

            // Dodaj nowe wydarzenia
            for (Event event : newlyAddedEvents) {
                insertStatement.setInt(1, event.getId());
                insertStatement.setString(2, event.getTitle());
                insertStatement.setDate(3, new java.sql.Date(event.getDate().getTime()));
                insertStatement.setString(4, event.getDescription());
                insertStatement.executeUpdate();
            }

            // Usuń wydarzenia z bazy danych
            for (Event event : deletedEvents) {
                deleteStatement.setInt(1, event.getId());
                deleteStatement.executeUpdate();
            }

            System.out.println("Wydarzenia zostały zapisane do bazy danych.");
            editedEvents.clear();
            newlyAddedEvents.clear();
            deletedEvents.clear();
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się zapisać wydarzeń do bazy danych!");
        }
    }

    
    /**
     * Wyświetla alert z podanym tytułem i wiadomością.
     * 
     * @param title   tytuł alertu.
     * @param message treść alertu.
     */

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }



    /**
     * Otwiera okno dialogowe do dodania lub edycji wydarzenia.
     * Jeśli wydarzenie jest null, otwiera dialog dodawania wydarzenia.
     * Jeśli wydarzenie jest nie-null, otwiera dialog edycji wydarzenia i aktualizuje dane.
     * 
     * @param event obiekt Event do edycji lub null, jeśli dodawane jest nowe wydarzenie.
     */

    private void openEventDialog(Event event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/WarstwaInterfejsu/EventDialog.fxml"));
            VBox dialogVBox = loader.load();

            EventDialogController dialogController = loader.getController();
            dialogController.setEvent(event);

            Stage dialogStage = new Stage();
            dialogStage.initModality(Modality.APPLICATION_MODAL);
            dialogStage.setTitle(event == null ? "Dodaj wydarzenie" : "Edytuj wydarzenie");
            dialogStage.setScene(new Scene(dialogVBox));
            dialogStage.showAndWait();

            if (dialogController.isConfirmed()) {
                Event newEvent = dialogController.getEvent();
                if (event == null) {
                    eventList.add(newEvent); // Dodanie do listy w pamięci
                } else {
                    eventList.remove(event); // Usuń stare wydarzenie
                    eventList.add(newEvent); // Dodaj zaktualizowane wydarzenie
                }
                eventTableView.refresh(); // Odśwież widok tabeli
            }
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Błąd", "Nie udało się otworzyć okna dialogowego!");
        }
    }

    
    
    /**
     * Obsługuje zapis nowego wydarzenia z pól tekstowych do listy wydarzeń.
     * Jeśli któreś pole jest puste, wyświetla alert o błędzie.
     */
    
    @FXML
    private void handleSaveEvent() {
        String name = eventNameField.getText();
        String date = eventDateField.getText();
        String description = eventDescriptionField.getText();

        if (name.isEmpty() || date.isEmpty() || description.isEmpty()) {
            showAlert("Błąd", "Wszystkie pola muszą być wypełnione!");
            return;
        }

        // Dodaj wydarzenie do listy w pamięci
        Event newEvent = new Event(name, java.sql.Date.valueOf(date), description);
        eventList.add(newEvent);

        // Odśwież tabelę w programie
        eventTableView.setItems(eventList);
        clearInputFields();
    }

    /**
     * Obsługuje anulowanie operacji dodawania lub edycji wydarzenia.
     * Czyści pola tekstowe i wyświetla alert informujący o anulowaniu operacji.
     */

    @FXML
    private void handleCancelEvent() {
        clearInputFields();
        showAlert("Anulowano", "Operacja została anulowana.");
    }

    /**
     * Czyści wszystkie pola tekstowe w formularzu dodawania lub edycji wydarzenia.
     */
    
    private void clearInputFields() {
        eventNameField.clear();
        eventDateField.clear();
        eventDescriptionField.clear();
    }

    
    
    /**
     * Wczytuje wydarzenia z pliku XML do listy `eventList`.
     *
     * @param filePath ścieżka do pliku XML, z którego wydarzenia zostaną wczytane
     */
    
    public void saveEventsToXml(String filePath) {
        XMLOutputFactory factory = XMLOutputFactory.newInstance();

        try (Writer fileWriter = new FileWriter(filePath)) {
            XMLStreamWriter writer = factory.createXMLStreamWriter(fileWriter);

            writer.writeStartDocument("1.0");
            writer.writeCharacters("\n");
            writer.writeStartElement("Events");
            writer.writeCharacters("\n");

            for (Event event : eventList) {
                writer.writeStartElement("Event");

                writer.writeStartElement("Title");
                writer.writeCharacters(event.getTitle());
                writer.writeEndElement();

                writer.writeStartElement("Date");
                writer.writeCharacters(event.getDate().toString());
                writer.writeEndElement();

                writer.writeStartElement("Description");
                writer.writeCharacters(event.getDescription());
                writer.writeEndElement();

                writer.writeEndElement(); // Event
                writer.writeCharacters("\n");
            }

            writer.writeEndElement(); // Events
            writer.writeEndDocument();

            writer.close();
            System.out.println("Wydarzenia zapisane do pliku XML: " + filePath);
        } catch (Exception e) {
            System.out.println("Błąd zapisu wydarzeń do XML: " + e.getMessage());
        }
   }

    
    /**
     * Obsługuje kliknięcie przycisku odczytu wydarzeń z pliku XML.
     * Wywołuje okno dialogowe do wyboru pliku, a następnie wczytuje wydarzenia.
     */
    
    @FXML
    private void handleSaveEventsToXmlButtonAction() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Zapisz wydarzenia do XML");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Pliki XML", "*.xml"));
        File file = fileChooser.showSaveDialog(null);

        if (file != null) {
            saveEventsToXml(file.getAbsolutePath());
        }
    }


}

    

