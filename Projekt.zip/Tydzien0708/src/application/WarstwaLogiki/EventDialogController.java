package application.WarstwaLogiki;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import application.WarstwaDanych.Event;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
	/**
	 * Kontroler dialogu dla dodawania i edycji wydarzeń.
	 * Odpowiada za zarządzanie interfejsem dialogowym i walidację danych.
	 */
public class EventDialogController {
	
	/**
	 * Kontroler dialogu dla dodawania i edycji wydarzeń.
	 * Odpowiada za zarządzanie interfejsem dialogowym i walidację danych.
	 */
    @FXML
    private TextField nameField;
    /**
     * Kontrolka do wyboru daty wydarzenia.
     * Powiązana z elementem FXML o fx:id="datePicker".
     */
    @FXML
    private DatePicker datePicker;
    /**
     * Pole tekstowe do wprowadzania opisu wydarzenia.
     * Powiązane z elementem FXML o fx:id="descriptionField".
     */
    @FXML
    private TextField descriptionField;
    
    /**
     * Obiekt reprezentujący wydarzenie.
     * Przechowuje dane wprowadzone lub edytowane w formularzu.
     */
    private Event event;
    /**
     * Flaga wskazująca, czy zmiany zostały potwierdzone.
     */
    private boolean confirmed = false;
    
    /**
     * Ustawia dane wydarzenia w polach formularza.
     * 
     * @param event obiekt Event do wyświetlenia lub edycji.
     */
    
    public void setEvent(Event event) {
        this.event = event;
        if (event != null) {
            nameField.setText(event.getTitle()); 
            if (event.getDate() != null) {
                // Konwersja java.util.Date na LocalDate
                LocalDate localDate = event.getDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                datePicker.setValue(localDate);
            } else {
                datePicker.setValue(null);
            }
            descriptionField.setText(event.getDescription());
        }
    }
    
    /**
     * Obsługuje zapis danych w formularzu.
     * Waliduje dane, tworzy nowe wydarzenie lub aktualizuje istniejące, a następnie zamyka okno dialogowe.
     */
    
    @FXML
    private void save() {
        if (validateFields()) {
            if (event == null) {
                // Tworzenie nowego wydarzenia
                event = new Event(
                        nameField.getText(),
                        convertToDate(datePicker.getValue()), // Konwersja LocalDate na java.util.Date
                        descriptionField.getText()
                );
            } else {
                // Aktualizacja istniejącego wydarzenia
                event.setTitle(nameField.getText());
                event.setDate(convertToDate(datePicker.getValue())); // Konwersja LocalDate na java.util.Date
                event.setDescription(descriptionField.getText());
            }
            confirmed = true;
            closeDialog();
        }
    }
    
    /**
     * Anuluje operację edycji lub dodawania wydarzenia.
     * Zamyka okno dialogowe bez zapisania zmian.
     */
    
    @FXML
    private void cancel() {
        // Zamykanie okna dialogowego bez zapisania zmian
        closeDialog();
    }
    
    /**
     * Zamyka okno dialogowe.
     */
    
    private void closeDialog() {
        Stage stage = (Stage) nameField.getScene().getWindow();
        stage.close();
    }
    
    /**
     * Waliduje pola formularza.
     * Sprawdza, czy wszystkie wymagane pola są wypełnione.
     * 
     * @return true, jeśli wszystkie pola są poprawnie wypełnione; false w przeciwnym wypadku.
     */
    
    private boolean validateFields() {
        if (nameField.getText().isEmpty() || datePicker.getValue() == null || descriptionField.getText().isEmpty()) {
            showAlert("Błąd", "Wszystkie pola muszą być wypełnione!");
            return false;
        }
        return true;
    }
    
    /**
     * Wyświetla alert z podanym tytułem i wiadomością.
     * 
     * @param title   tytuł alertu.
     * @param message treść wiadomości alertu.
     */
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    /**
     * Sprawdza, czy zmiany w formularzu zostały zapisane.
     * 
     * @return true, jeśli zmiany zostały zapisane; false w przeciwnym wypadku.
     */
    
    public boolean isConfirmed() {
        return confirmed;
    }
    
    /**
     * Pobiera dane wydarzenia wprowadzone w formularzu.
     * 
     * @return obiekt Event na podstawie danych z formularza.
     */
    
    public Event getEvent() {
        return event;
    }
    
    /**
     * Konwertuje LocalDate na java.util.Date.
     * 
     * @param localDate data w formacie LocalDate.
     * @return data w formacie java.util.Date lub null, jeśli localDate jest null.
     */
    
    // Konwersja LocalDate na java.util.Date
    private Date convertToDate(LocalDate localDate) {
        return localDate != null ? Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant()) : null;
    }
}
