package application.WarstwaLogiki;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.Calendar;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import application.WarstwaDanych.Contact;
import application.WarstwaDanych.Event;
import application.WarstwaDanych.ResultSet;
import application.WarstwaDanych.Statement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

/**
 * Tworzy obiekt klasy Kalendarz.
 * Inicjalizuje listy kontaktów i wydarzeń oraz przypisuje dane domyślne.
 */

public class Kalendarz {

    private ArrayList<Contact> contacts;
    private ArrayList<Event> events;

    public Kalendarz() {
        contacts = new ArrayList<>();
        events = new ArrayList<>();
        initData();
    }
    
    /**
     * Inicjalizuje dane kontaktów i wydarzeń na sztywno.
     * Dodaje przykładowe kontakty i wydarzenia do list.
     */
    
    // Przypisywanie na sztywno 
    private void initData() {
    	 contacts.add(new Contact("Jan", "Kowalski", "212321312", "Rodzina"));
    	 contacts.add(new Contact("Anna", "Nowak", "765987453", "Znajomi"));
    	 contacts.add(new Contact("Kacper", "Kazmierczak", "987567456", "Praca"));
    	 contacts.add(new Contact("Michal", "Polujanski", "123456789", "Znajomi"));
    	 contacts.add(new Contact("Ewa", "Malinowska", "321654987", "Rodzina"));
    	 contacts.add(new Contact("Tomasz", "Wilk", "654987321", "Szkoła"));
    	 contacts.add(new Contact("Piotr", "Zajac", "789456123", "Praca"));
         contacts.add(new Contact("Katarzyna", "Lis", "963852741", "Inne"));
    	 contacts.add(new Contact("Agnieszka", "Luk", "741852963", "Znajomi"));
    	 contacts.add(new Contact("Marek", "Kwiatkowski", "852741963", "Rodzina"));
        
        //uzycie createDate bo Date jest przestarzale i podkresla jako warning
        events.add(new Event("Urodziny", createDate(2024, Calendar.NOVEMBER, 14), "Janek 23 lata"));
        events.add(new Event("Wykład", createDate(2024, Calendar.NOVEMBER, 11), "Programowanie komponentowe"));
        events.add(new Event("Projekt", createDate(2024, Calendar.NOVEMBER, 12), "Bazy Danych"));
        events.add(new Event("Imieniny", createDate(2024, Calendar.NOVEMBER, 13), "Imieniny Anii"));
        events.add(new Event("Spotkanie biznesowe", createDate(2024, Calendar.NOVEMBER, 15), "Spotkanie o godz 15.00"));
        events.add(new Event("Warsztaty", createDate(2024, Calendar.NOVEMBER, 16), "Warsztaty kompetencje społeczne"));
        events.add(new Event("Wakacje", createDate(2025, Calendar.JUNE, 20), "Wakacje w Rzymie"));
        events.add(new Event("Ślub", createDate(2025, Calendar.JULY, 5), "Ceremonia w kościele"));
        events.add(new Event("Konferencja", createDate(2024, Calendar.DECEMBER, 1), "Konferencja w Warszawie"));
        events.add(new Event("Kolacja wigilijna", createDate(2024, Calendar.DECEMBER, 24), "Kolacja u rodziców 16.00"));
    }
    
    /**
     * Tworzy obiekt Date na podstawie roku, miesiąca i dnia.
     * 
     * @param year  rok.
     * @param month miesiąc (0-indexed).
     * @param day   dzień.
     * @return obiekt Date reprezentujący podaną datę.
     */
    
    private Date createDate(int year, int month, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day, 0, 0, 0); 
        calendar.set(Calendar.MILLISECOND, 0); 
        return calendar.getTime();
    }
    
    /**
     * Pobiera listę kontaktów.
     * 
     * @return lista kontaktów.
     */
    
    // Gettery dla kontaktow i wydarzen
    public ArrayList<Contact> getContacts() {
        return contacts;
    }
    
    /**
     * Pobiera listę wydarzeń.
     * 
     * @return lista wydarzeń.
     */
    
    public ArrayList<Event> getEvents() {
        return events;
    }

    /**
     * Dodaje nowy kontakt do listy kontaktów.
     * 
     * @param firstName  imię kontaktu.
     * @param lastName   nazwisko kontaktu.
     * @param phoneNumber numer telefonu kontaktu.
     * @param category   kategoria kontaktu.
     */
    
    // Dodawanie kontaktu
    public void addContact(String firstName, String lastName, String phoneNumber, String category) {
        contacts.add(new Contact(firstName, lastName, phoneNumber, category));
    }

    
    /**
     * Dodaje nowe wydarzenie do listy wydarzeń.
     * 
     * @param title       tytuł wydarzenia.
     * @param date        data wydarzenia w formacie "yyyy-MM-dd".
     * @param description opis wydarzenia.
     */
    
    // Dodawanie wydarzenia
    public void addEvent(String title, String date, String description) {
        try {
            String[] parts = date.split("-");
            int year = Integer.parseInt(parts[0]) - 1900;
            int month = Integer.parseInt(parts[1]) - 1;
            int day = Integer.parseInt(parts[2]);

            events.add(new Event(title, createDate(year, month, day), description));
        } catch (Exception e) {
            System.out.println("Błąd parsowania daty: " + e.getMessage());
        }
    }
    
    /**
     * Edytuje istniejący kontakt na liście kontaktów.
     * 
     * @param index          indeks kontaktu w liście.
     * @param newFirstName   nowe imię kontaktu.
     * @param newLastName    nowe nazwisko kontaktu.
     * @param newPhoneNumber nowy numer telefonu kontaktu.
     * @param newCategory    nowa kategoria kontaktu.
     */
    

    // Edycja kontaktu
    public void editContact(int index, String newFirstName, String newLastName, String newPhoneNumber, String newCategory) {
        if (index >= 0 && index < contacts.size()) {
            contacts.get(index).setFirstName(newFirstName);
            contacts.get(index).setLastName(newLastName);
            contacts.get(index).setPhoneNumber(newPhoneNumber);
            contacts.get(index).setCategory(newCategory);
        } else {
            System.out.println("Nieprawidlowy indeks kontaktu.");
        }
    }
    
    /**
     * Edytuje istniejące wydarzenie na liście wydarzeń.
     * 
     * @param index          indeks wydarzenia w liście.
     * @param newTitle       nowy tytuł wydarzenia.
     * @param newDate        nowa data wydarzenia w formacie "yyyy-MM-dd".
     * @param newDescription nowy opis wydarzenia.
     */

    // Edycja wydarzenia
    public void editEvent(int index, String newTitle, String newDate, String newDescription) {
        if (index >= 0 && index < events.size()) {
            Event event = events.get(index);
            try {
                String[] parts = newDate.split("-");
                int year = Integer.parseInt(parts[0]) - 1900;
                int month = Integer.parseInt(parts[1]) - 1;
                int day = Integer.parseInt(parts[2]);

                event.setTitle(newTitle);
                event.setDate(createDate(year, month, day));
                event.setDescription(newDescription);
            } catch (Exception e) {
                System.out.println("Błąd parsowania daty: " + e.getMessage());
            }
        } else {
            System.out.println("Nieprawidłowy indeks wydarzenia.");
        }
    }
    	
    /**
     * Zapisuje listę kontaktów do bazy danych.
     */
    
    //ZAPIS DO BAZY DANYCH Z LIST, POTRZEBNE DO TRYBU TEKSTOWEGO
    public void saveContactsToDatabase() {
        String url = "jdbc:mysql://localhost:3306/kalendarz"; 
        String user = "root"; 
        String password = ""; 

        String sql = "INSERT INTO contact (imie, nazwisko, nr_tel, kategoria) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            for (Contact contact : contacts) {
                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setString(1, contact.getFirstName());
                    pstmt.setString(2, contact.getLastName());
                    pstmt.setString(3, contact.getPhoneNumber());
                    pstmt.setString(4, contact.getCategory());
                    pstmt.executeUpdate();
                }
            }
            System.out.println("Kontakty zapisane do bazy danych.");
        } catch (SQLException e) {
            System.out.println("Błąd podczas zapisu kontaktów do bazy danych: " + e.getMessage());
        }
    }
    
    /**
     * Zapisuje listę wydarzeń do bazy danych.
     */
    
    public void saveEventsToDatabase() {
        String url = "jdbc:mysql://localhost:3306/kalendarz"; 
        String user = "root"; 
        String password = ""; 

        String sql = "INSERT INTO events (nazwa, data, opis) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            for (Event event : events) {
                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setString(1, event.getTitle());
                    pstmt.setDate(2, new java.sql.Date(event.getDate().getTime()));
                    pstmt.setString(3, event.getDescription());
                    pstmt.executeUpdate();
                }
            }
            System.out.println("Wydarzenia zapisane do bazy danych.");
        } catch (SQLException e) {
            System.out.println("Błąd podczas zapisu wydarzeń do bazy danych: " + e.getMessage());
        }
    }

    /**
     * Zapisuje listę kontaktów do pliku tekstowego.
     * 
     * @param filePath ścieżka do pliku, w którym mają zostać zapisane kontakty.
     */    

 // ZAPIS DO PLIKU TXT
    public void saveContactsToFile(String filePath) {
        File file = new File(filePath);
        StringBuilder tekstDoZapisania = new StringBuilder();

        for (Contact contact : contacts) {
            tekstDoZapisania.append("Imie: ").append(contact.getFirstName())
                            .append(", Nazwisko: ").append(contact.getLastName())
                            .append(", Telefon: ").append(contact.getPhoneNumber())
                            .append(", Kategoria: ").append(contact.getCategory())
                            .append("\n");
        }

        try {
            file.createNewFile();
            FileWriter strumienZapisu = new FileWriter(file);
            strumienZapisu.write(tekstDoZapisania.toString());
            strumienZapisu.close();
            System.out.println("Kontakty zapisane do pliku TXT: " + filePath);
        } catch (IOException io) {
            System.out.println("Blad zapisu: " + io.getMessage());
        }
    }

    
    /**
     * Odczytuje listę kontaktów z pliku tekstowego.
     * 
     * @param filePath ścieżka do pliku, z którego mają zostać odczytane kontakty.
     */

 // ODCZYT Z PLIKU TXT
    public void readContactsFromFile(String filePath) {
        File file = new File(filePath);

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            contacts.clear(); // Czyszczenie listy kontaktów przed odczytem
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", ");
                if (parts.length == 4) {
                    String firstName = parts[0].split(": ")[1];
                    String lastName = parts[1].split(": ")[1];
                    String phoneNumber = parts[2].split(": ")[1];
                    String category = parts[3].split(": ")[1];
                    contacts.add(new Contact(firstName, lastName, phoneNumber, category));
                }
            }
            System.out.println("Kontakty odczytane z pliku TXT: " + filePath);
        } catch (IOException e) {
            System.out.println("Blad odczytu: " + e.getMessage());
        }
    }

    /**
     * Zapisuje listę kontaktów i wydarzeń do pliku XML.
     * 
     * @param filePathXML ścieżka do pliku XML, w którym mają zostać zapisane dane.
     */
    
//ZAPIS DO PLIKU XML    
    public void saveToXml(String filePathXML) {
        XMLOutputFactory factory = XMLOutputFactory.newInstance();

        try (Writer fileWriter = new FileWriter(filePathXML)) {
            XMLStreamWriter writer = factory.createXMLStreamWriter(fileWriter);

            writer.writeStartDocument("1.0");
            writer.writeCharacters("\n");
            writer.writeStartElement("Kalendarz");
            writer.writeCharacters("\n");

            // Zapis kontaktów
            writer.writeStartElement("Contacts");
            writer.writeCharacters("\n");
            for (Contact contact : contacts) {
                writer.writeStartElement("Contact");
                writer.writeStartElement("FirstName");
                writer.writeCharacters(contact.getFirstName());
                writer.writeEndElement();
                writer.writeStartElement("LastName");
                writer.writeCharacters(contact.getLastName());
                writer.writeEndElement();
                writer.writeStartElement("PhoneNumber");
                writer.writeCharacters(contact.getPhoneNumber());
                writer.writeEndElement();
                writer.writeStartElement("Category");
                writer.writeCharacters(contact.getCategory());
                writer.writeEndElement();
                writer.writeEndElement(); // Contact
                writer.writeCharacters("\n");
            }
            writer.writeEndElement(); // Contacts
            writer.writeCharacters("\n");

            // Zapis wydarzeń
            writer.writeStartElement("Events");
            writer.writeCharacters("\n");
            for (Event event : events) {
                writer.writeStartElement("Event");
                writer.writeStartElement("Title");
                writer.writeCharacters(event.getTitle());
                writer.writeEndElement();
                writer.writeStartElement("Date");
                writer.writeCharacters(event.getDate().toString());
                writer.writeEndElement();
                writer.writeEndElement(); // Event
                writer.writeCharacters("\n");
            }
            writer.writeEndElement(); // Events
            writer.writeCharacters("\n");

            writer.writeEndElement(); // Kalendarz
            writer.writeEndDocument();

            writer.close();
            System.out.println("Kontakty i wydarzenia zapisane do XML: " + filePathXML);
        } catch (Exception e) {
            System.out.println("Błąd zapisu do XML: " + e.getMessage());
        }
    }

    /**
     * Odczytuje listę kontaktów i wydarzeń z pliku XML.
     * 
     * @param filePathXML ścieżka do pliku XML, z którego mają zostać odczytane dane.
     */

    //ODCZYT Z PLIKU XML
    public void loadFromXml(String filePathXML) {
        XMLInputFactory factory = XMLInputFactory.newInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH);

        try (FileReader fileReader = new FileReader(filePathXML)) {
            XMLStreamReader reader = factory.createXMLStreamReader(fileReader);

            String currentElement = "";
            String firstName = null, lastName = null, phoneNumber = null, category = null;
            String eventName = null;
            Date eventDate = null;

            contacts.clear(); // Czyszczenie listy kontaktow przed odczytem
            events.clear();   // Czyszczenie listy wydarzen przed odczytem

            while (reader.hasNext()) {
                int event = reader.next();

                if (event == XMLStreamReader.START_ELEMENT) {
                    currentElement = reader.getLocalName();
                } else if (event == XMLStreamReader.CHARACTERS) {
                    switch (currentElement) {
                        case "FirstName":
                            firstName = reader.getText().trim();
                            break;
                        case "LastName":
                            lastName = reader.getText().trim();
                            break;
                        case "PhoneNumber":
                            phoneNumber = reader.getText().trim();
                            break;
                        case "Category":
                            category = reader.getText().trim();
                            break;
                        case "Title":
                            eventName = reader.getText().trim();
                            break;
                        case "Date":
                            try {
                                eventDate = dateFormat.parse(reader.getText().trim());
                            } catch (Exception e) {
                                eventDate = null;
                            }
                            break;
                    }
                } else if (event == XMLStreamReader.END_ELEMENT) {
                    if ("Contact".equals(reader.getLocalName())) {
                        if (firstName != null && lastName != null && phoneNumber != null && category != null) {
                            contacts.add(new Contact(firstName, lastName, phoneNumber, category));
                        }
                        firstName = null;
                        lastName = null;
                        phoneNumber = null;
                        category = null;
                    } else if ("Event".equals(reader.getLocalName())) {
                        if (eventName != null && eventDate != null) {
                            events.add(new Event(eventName, eventDate, ""));
                        }
                        eventName = null;
                        eventDate = null;
                    }
                }
            }

            reader.close();
            System.out.println("Kontakty i wydarzenia odczytane z XML: " + filePathXML);

            // Wyswietlanie kontaktow
            System.out.println("\nKontakty:");
            for (Contact contact : contacts) {
                System.out.println("Imię: " + contact.getFirstName() +
                                   ", Nazwisko: " + contact.getLastName() +
                                   ", Telefon: " + contact.getPhoneNumber() +
                                   ", Kategoria: " + contact.getCategory());
            }

            // Wyswietlanie wydarzen
            System.out.println("\nZdarzenia:");
            for (Event event : events) {
                System.out.println("Tytul: " + event.getTitle() + ", Data: " + event.getDate());
            }

        } catch (Exception e) {
            System.out.println("Blad odczytu z XML: " + e.getMessage());
        }
    }


    /**
     * Sortuje listę kontaktów alfabetycznie według imienia i nazwiska.
     */

    // Sortowanie kontaktow i wydarzen za pomoca Collections.sort
    public void sortContactsByName() {
        Collections.sort(contacts);
    }
    
    /**
     * Sortuje listę wydarzeń chronologicznie według daty.
     */
    
    public void sortEventsByDate() {
        Collections.sort(events);
    }

    
    /**
     * Wyświetla listę kontaktów na konsoli.
     */
    
    // Wyswietlanie
    public void displayContacts() {
        System.out.println("\nKontakty:");
        for (int i = 0; i < contacts.size(); i++) {
            System.out.println(i + ": " + contacts.get(i));
        }
    }
    
    /**
     * Wyświetla listę wydarzeń na konsoli.
     */
    
    public void displayEvents() {
        System.out.println("\nWydarzenia:");
        for (int i = 0; i < events.size(); i++) {
            System.out.println(i + ": " + events.get(i));
        }
    }
    
    /**
     * Główna metoda aplikacji.
     * Demonstruje funkcjonalności klasy Kalendarz, takie jak:
     * - Połączenie z bazą danych.
     * - Wykonanie zapytania SQL i wyświetlenie wyników.
     * - Sortowanie kontaktów i wydarzeń.
     * - Dodawanie nowych kontaktów i wydarzeń.
     * - Zapis i odczyt kontaktów z plików TXT i XML.
     * 
     * @param args argumenty wiersza poleceń (nieużywane).
     */

    // Funkcja main
    public static void main(String[] args) {
        Kalendarz kalendarz = new Kalendarz();

        // Polaczenie z baza danych
        Connection connection = null;
        Statement statement = null;
        ResultSet myResultSet = null; 

        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/kalendarz", "root", "");
            System.out.println("Polaczono z baza danych.");

            // Tworzenie Statement
            statement = new Statement(connection);

            // Wykonanie zapytania SELECT i przekazanie do ResultSet
            String query = "SELECT * FROM contact";
            myResultSet = new ResultSet(statement.executeQuery(query));
            

            // Wywolanie metody printResults()
            myResultSet.printResults();

        } catch (SQLException e) {
            System.err.println("Blad SQL: " + e.getMessage());
        } finally {
            // Zamkniecie zasobow
            try {
                if (myResultSet != null) myResultSet.close();
                if (statement != null) statement.close();
                if (connection != null) {
                    connection.close();
                    System.out.println("Polaczenie z baza zamkniete.");
                }
            } catch (SQLException e) {
                System.err.println("Blad zamykania zasobow: " + e.getMessage());
            }
        }
        
        // Sortowanie kontaktow
        System.out.println("Kontakty wedlug imienia:");
        kalendarz.sortContactsByName();
        kalendarz.displayContacts();

        // Sortowanie wydarzen
        System.out.println("\nWydarzenia wedlug daty:");
        kalendarz.sortEventsByDate();
        kalendarz.displayEvents();

        // Dodawanie przykladowych kontaktow i wydarzen
        kalendarz.addContact("Piotr", "Kowalski", "123123123", null);
        kalendarz.addEvent("Spotkanie", "2024-11-20", "Piwo bar 19.00");

        System.out.println("\nPo dodaniu nowego kontaktu i wydarzenia:");
        kalendarz.displayContacts();
        kalendarz.displayEvents();

        String filePath = "contacts.txt";

        // Zapis kontaktow do pliku TXT
        kalendarz.saveContactsToFile(filePath);
        // Odczyt kontaktow z pliku TXT
        kalendarz.readContactsFromFile(filePath);
        
        // Zapis kontaktow do XML
        String filePathXML = "zapis.xml";
        kalendarz.saveToXml(filePathXML);

        // Wyczyszczenie listy i odczyt kontaktow z XML
        kalendarz.loadFromXml(filePathXML);
    }
}
